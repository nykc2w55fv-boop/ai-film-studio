# 13. AI 适配与制作管线（AI Adaptation and Pipeline）

> **方法论性质声明**：本文件提供的所有 AI 图像生成、AI 视频生成、提示词结构（Prompt Structure）以及自动化节点管线方案，均是由研究员团队基于 John Knoll 的核心视觉特效原则（如“物理光照参考优先”[A级]、“按任务选工具的混合制作”[A级]、“现场真人替身优先”[A级]、“记忆对齐与风格册约束”[A级]）所设计的**现代 AI 工程转译方案**，并非 John Knoll 本人在历史项目中的原始做法。

---

## 一、 工具无关与软件实现层架构说明

本管线遵循“先定义工具无关（Tool-Agnostic）的数据契约与物理规律，再映射到具体现代制作工具”的工程原则：
*   **工具无关层**：定义剧本拆解数据、摄影机与光照物理元数据、图层遮挡关系与验收指标。这对应 Knoll 在前期与摄影指导（DP）、导演排雷的制片逻辑 [A级]。
*   **软件实现建议层**：
    *   **三维与物理预演**：Blender（承担虚拟布景漫游、数字零件库拼装、带物理约束的运动控制预演）。
    *   **环境采集与体积资产**：3D Gaussian Splatting（高斯泼溅，Knoll 已在《曼达洛人与古古》中引入正式管线 [A级]）与激光雷达扫描（LiDAR）。
    *   **AI 图像与视频辅助**：基于扩散模型（Diffusion Models）的受控图像管线（如 ComfyUI + ControlNet/IP-Adapter）及 AI 视频生成工具（仅作特定受控层或动态参考，严禁替代精确合成）。
    *   **专业节点合成**：Nuke 或 Fusion（承担多通道 EXR 合成、3D 跟踪匹配、色彩空间管理与胶片颗粒统一）。

---

## 二、 模块 A：剧本到 VFX Breakdown（输入/输出字段规范）

本模块模拟 Knoll 在开机前 6 个月介入项目、阅读剧本并与导演及摄影指导确定制作方案的过程 [A级]。

### 1. 输入字段（Input Schema）
| 字段名 | 类型 | 说明与物理/叙事指向 |
| :--- | :--- | :--- |
| `scene_id` | String | 场次编号（如 `SC_014_INT_TANTIVE_CORRIDOR`）。 |
| `script_text` | Text | 原始剧本段落（含环境描写、动作、对白）。 |
| `narrative_weight` | Enum | 叙事权重：`Core_Story`（核心叙事）/ `World_Building`（世界观建立）/ `Transition`（过渡）。用于判断资源投入比 [A级]。 |
| `screen_time_est` | Float | 预计银幕停留时长（秒）及预计镜头数（用于核算搭景成本是否能够分摊/justify）[A级]。 |
| `director_shooting_style`| Enum | 导演拍摄风格：`Locked_Previs`（严谨预演锁定）/ `Documentary_Handheld`（纪录片式手持即兴抓拍，如《侠盗一号》Gareth Edwards 风格）[A级]。 |
| `era_style_book_ref` | String | 关联的“传承风格册”（Legacy Style Book）编号，定义年代光学与工艺质感基准 [A级]。 |

### 2. 输出字段（Output Schema - VFX Breakdown 单）
| 字段名 | 类型 | 说明与 Knoll 方法论依据 |
| :--- | :--- | :--- |
| `vfx_methodology_route` | Enum | 路由决策：`Full_Practical`（全实拍，如白色走廊打光难且成本接近时）[A级] / `Partial_FoamCore_SetExt`（局部泡沫板实体参照 + 数字扩展）[A级] / `Miniature_LED_Stage`（微缩模型 + LED 同步棚）[A级/B级] / `Gaussian_Splatting_Capture`（实景高斯泼溅采集供后期任意机位调用）[A级] / `Full_CG`（纯数字）。 |
| `on_set_proxy_req` | Object | 现场实体替身要求：是否需要真人演员穿动捕服及视线增高装置（如 K-2SO 电动高跷）[A级]；是否需要泡沫板（Foam Core）提供受光面与取景框参照 [A级]。 |
| `lighting_trap_warning` | Array | 前期摄影排雷警告（如：“禁止在棚内用纯蓝幕拍白天窗外景，防曝光比失控打爆窗台”[A级]；“面部捕捉禁用白光 LED，必须改用红外摄像机+红外补光”[A级]）。 |
| `asset_lock_dependency` | String | 资产锁定依赖：标注“待美术部门搭完实景后进行激光扫描，严禁前期与美术并行盲建两套不一致模型”[A级]。 |

---

## 三、 模块 B：镜头级特效设计单（Shot-Level VFX Spec）

每个进入制作管线的特效镜头必须生成以下标准 JSON/表格结构，确保从现场到后期数据闭环：

| 规范字段 | 字段定义与填写标准 |
| :--- | :--- |
| **`shot_id`** | 唯一镜头标识（如 `RO_042_010`，包含序列号与镜头号）。 |
| **`原始画面 (Raw Plate)`** | 描述现场实拍底片内容：包含真人演员、局部泡沫板布景、红外动捕标记点、真实环境光照明（严禁只有无参照的大面积蓝/绿幕）[A级]。 |
| **`目标画面 (Target Final)`**| 描述成片最终视觉状态及对齐的“观众记忆基准”（Match memory more than reality）[A级]。 |
| **`特效目标 (VFX Objective)`**| 明确该镜头特效解决的具体叙事或视觉问题（如：将局部泡沫板舰桥扩展为深挚号全景，同时保留演员脸部真实的控制台交互光）[A级]。 |
| **`前景元素 (Foreground)`** | 位于主体前的实拍或 CG 遮挡物（如：实拍的前景人物肩部、漂浮烟尘、控制面板局部）。 |
| **`背景元素 (Background)`** | 远景环境（如：数字星海、行星大气、高斯泼溅重建的飞船内舱深处、或合成进来的远景微缩模型通道）[A级/B级]。 |
| **`CG 元素 (CG Assets)`** | 纯三维渲染资产（如：用扫描塑料套件拼装库构建的歼星舰、全 CG 角色 K-2SO 或 Rotta）[A级]。 |
| **`实拍元素 (Practical)`** | 实拍底片保留部分、运动控制拍摄的 24/48 英寸微缩模型实拍层 [B级]、定格动画层 [A级]。 |
| **`遮挡关系 (Occlusion)`** | 明确从前到后的深度层级（Z-Order）及交互边缘（如：真人手臂遮挡 CG 机器人躯干，需精确 Roto 或深度通道切割）。 |
| **`光照/材质要求`** | 核心物理约束：针对高反射裸金属（如 Razor Crest 或曼达洛人头盔），明确反射源是来自太空单一硬光源还是大气层复杂云层漫反射 [A级/B级]；明确行星反光色温（Bounce Light）[B级]。 |
| **`摄影机参数 (Camera)`** | 画幅格式（如 45% 原生 IMAX 画幅或变形宽银幕）[A级]、焦距、T-Stop 光圈、快门角度、镜头畸变网格（Lens Distortion Grid）。 |
| **`运动要求 (Motion)`** | 摄影机运动轨迹（手持呼吸感或 Dykstraflex 式运动控制轨迹 [A级]）与角色物理运动参照（如参考象海豹 galumphing 的侧滚物理速度：瞬间滚过约 3.14 米）[A级]。 |
| **`合成要求 (Comp Req)`** | 曝光比匹配（室内暗部与窗外高亮日景的光学滚降）[A级]、黑位与暗部噪声对齐、边缘光晕（Light Wrap）与运动模糊匹配。 |
| **`验收标准 (Acceptance)`** | 达到“无法分辨是微缩模型还是 CG”的无痕融合状态 [B级]，且符合项目《传承风格册》的工艺质感 [A级]。 |

---

## 四、 模块 C：AI 图像与视频特效规范（研究者工程方案）

> **核心工程红线声明**：在任何工业级制作管线中，**不得假设 AI 视频模型能稳定完成逐像素合成（Pixel-accurate Compositing）与精确摄影机匹配（Exact Camera Matchmoving）**。AI 生成内容只能作为受控纹理输入、远景环境垫绘（Matte Painting）基底、前期概念参考或受严格深度/法线通道约束的局部填充层，最终合成必须回到确定性的三维与节点合成管线中完成。

### 1. 六大任务的标准化提示词结构（Prompt Structure）
所有提示词必须摒弃空洞的修饰词，采用**“物理材质 + 历史模型工艺 + 真实光学照明”**的结构化写法：

*   **① 场景扩展（Set Extension）**
    *   `[结构]`：`[实拍局部布景材质描述] + [扩展区模块化几何结构] + [传承风格册年代工艺特征] + [实拍主光方向与曝光比约束] + [镜头焦段与景深衰减]`
    *   `[示例]`：`Industrial sci-fi hangar extension, modular concentric steel panels, exposed conduits, bolts and exhaust vents, 1977 practical miniature kitbash aesthetic, lit by high-contrast overhead sodium vapor practical lights matching foreground plate exposure, 35mm anamorphic lens bokeh, subtle film grain.`
*   **② CG 元素概念与贴图生成（CG Elements & Kitbash Textures）**
    *   `[结构]`：`[模型套件表面细节类型] + [物理旧化与涂装磨损] + [非完美手工痕迹] + [正交无阴影漫反射光照 (Albedo)]`
    *   `[示例]`：`Close-up surface detail of starship hull panels, injection-molded plastic model kitbash greebles, hand-painted weathered grey enamel, subtle oil streaks around panel seams, flat even diffuse studio lighting for texture projection.`
*   **③ 数字角色视觉开发（Digital Characters VisDev）**
    *   `[结构]`：`[生物解剖与自然界真实物种参照] + [表皮物理次表面散射与湿度] + [与实拍环境一致的受光方向]`
    *   `[示例]`：`Muscular young Hutt gladiator physiology, heavy thick skin folds referencing elephant seal dermis, damp organic subsurface scattering, dramatic side-rim lighting from arena practical lamps, cinematic photorealism.`
*   **④ 环境替换（Environment Replacement / Sky & Planet Backdrop）**
    *   `[结构]`：`[大气光学密度与云层体积] + [主光源天体方位与色温] + [供金属表面反射的高动态范围特征]`
    *   `[示例]`：`Dense volumetric storm clouds of Nal Hutta, muddy amber and teal atmospheric scattering, diffused top-down celestial sunlight breaking through cloud layer, high dynamic range environment plate suitable for bare metal specular reflection.`
*   **⑤ 物体移除与干净底片修复（Object Removal / Clean Plate Inpainting）**
    *   `[结构]`：`[被遮挡背景的连续几何纹理] + [周围实拍底片的暗部颗粒与光学模糊特征] + [零新增人造结构指令]`
    *   `[示例]`：`Seamless continuation of weathered concrete landing pad texture, matching surrounding out-of-focus depth of field, preserving original sensor noise and shadow falloff, no additional props.`
*   **⑥ 镜头生成（Shot Generation - 仅限前期 Previs 情绪验证或远景非精密背景）**
    *   `[结构]`：`[运动控制摄影机运镜轨迹] + [主体与环境的相对运动物理约束] + [实拍模拟光源互动]`
    *   `[示例]`：`Motion-control style tracking shot following a silver bare-metal spacecraft banking through thick atmospheric clouds, dynamic cloud reflections sweeping across the metallic hull, simulated 50mm lens, physically grounded inertia.`

### 2. 多镜头一致性约束（Multi-Shot Consistency）的具体工程做法
为防止 AI 在连续镜头中产生闪烁与设计变异，必须执行以下三项硬编码锁定：
1.  **固定资产描述块（Fixed Asset Token Block）**：将经过审批的角色/飞船外观特征封装为不可更改的字符串常量（如 `$ASSET_RAZOR_CREST_V1`），并在管线中强制绑定同一组多视角参考图（IP-Adapter / Reference-Only 权重锁定）与三维深度/法线控制图（ControlNet Depth/Normal）。
2.  **固定光照与色温描述（Fixed Lighting & Kelvin Block）**：同一场戏的所有镜头共享同一个环境光照描述块（如 `$LIGHT_SC14_INT`：锁定主光角度、色温 3200K/5600K、环境漫反射颜色及室内外曝光光圈差），严禁单镜头随机发挥。
3.  **固定镜头语言描述（Fixed Lens & Format Block）**：锁定摄影机画幅（如 IMAX 1.43:1 或 2.39:1 变形宽银幕）、焦段组（如 35mm/50mm/85mm 定焦）、快门模糊角度（180度）以及统一的 LUT 与胶片颗粒模型。

---

## 五、 模块 D：Blender 三维制作规范（研究者工程方案）

本模块将 Knoll 的虚拟布景漫游 [A级]、扫描塑料零件库拼装（Kitbashing）[A级] 与微缩模型预演约束 [B级] 转化为 Blender 标准工程规范。

### 1. 九大核心技术规范
*   **场景结构（Scene Hierarchy）**：严格按集合（Collections）分层：`01_CAM_TRACK`（摄影机与跟踪点）、`02_LIDAR_PRACTICAL_REF`（现场激光扫描网格与泡沫板参考体，设为不可渲染仅作对齐）[A级]、`03_HERO_ASSETS`（核心数字资产）、`04_KITBASH_ENV`（模块化场景扩展）、`05_LIGHTS_ENV`（灯光与反射环境球）。
*   **资产清单（Asset Library）**：建立标准化 Blender Asset Browser 库。仿照 Knoll 在《侠盗一号》的做法，将扫描的模型套件零件（Greebles、管线、通风口、螺栓）分类入库 [A级][B级]，支持快速吸附拼装；同时维护“贴近外景标准版”与“贴近实景舱门比例版”的多版本分支资产（应对类似 U 翼的实景与外景比例差异问题）[A级]。
*   **相机参数（Camera Settings）**：严格输入现场记录的传感器尺寸（Sensor Size）、焦距与镜头畸变系数；对于手持纪录片风格镜头，导入 3D Matchmove 解算出的逐帧相机曲线；支持将视口实时输出至头显（仿照 Knoll 团队用 Apple Vision Pro 模拟 100 英尺 IMAX 银幕检查构图与头部空间）[A级]。
*   **比例（Scale & Unit）**：全局强制锁定 `1 Unit = 1.0 Meter`。若用于指导微缩模型拍摄预演，必须在场景中同时建立 1:1 真实世界比例尺与 24 英寸/48 英寸微缩模型比例尺的转换约束框，并添加运动控制机械臂的物理限位约束（防止动画师做出实体模型无法实现的运镜）[B级]。
*   **材质（Materials & Shaders）**：基于 Cycles 物理渲染器构建 PBR 材质。裸金属表面必须通过粗糙度贴图（Roughness）、各向异性（Anisotropy）与微划痕法线展现手工艺感；严格遵循《传承风格册》，拒绝过度光滑的塑料 CG 感 [A级][B级]。
*   **灯光（Lighting）**：允许并鼓励“物理基础上的电影化造假”——正如《曼达洛人与古古》团队所言，太空中理论上只有一个太阳硬光源，但为了让闪亮金属显出细节，必须在 Blender 中像拍汽车广告一样架设大面积柔光面光源（Area Lights with Softbox textures）、边缘轮廓光（Rim Light）以及模拟行星表面的彩色反弹光（Colored Bounce Light）[B级]。
*   **反射环境（Reflection Environment）**：针对高反射资产，严禁使用单调的默认天空球。必须加载现场采集的高动态范围全景图（HDRI）或与摄影机运动逐帧同步的动态环境序列（模拟微缩 LED 棚随相机推进逐帧刷新反射的机制）[A级]。
*   **阴影（Shadows）**：使用 Shadow Catcher（阴影捕捉器）承接实拍泡沫板或地面扫描网格上的投射阴影，确保软硬虚实过渡与现场主光尺寸严格匹配。
*   **渲染通道（Render Passes / AOVs）**：强制输出多层 32-bit Float OpenEXR，必须包含：`Combined`、`Diffuse_Direct/Indirect`、`Glossy_Direct/Indirect`（极其关键，用于合成师单独调控裸金属反射强度）、`Emission`、`Shadow_Catcher`、`Z-Depth`、`Vector`（运动矢量）、`Normal`、`Cryptomatte`（按物体/材质精准分离遮罩）。

### 2. Blender 能力边界划分（何时独立完成 / 何时进合成 / 何时必须实拍）
| 任务类型 | 制作路径划分 | 依据与物理/制片原因 |
| :--- | :--- | :--- |
| **Blender 可独立完成（直出可用）** | 1. 前期虚拟布景可漫游渲染与导演信心验证 [A级]；<br>2. 微缩模型实拍前的三维运动控制预演蓝图（Mock-up）[B级]；<br>3. 纯全数字远景镜头或高机动太空追逐纯 CG 镜头的基础渲染 [B级]。 | 不涉及真人前景与实拍底片复杂光学交融，或仅用于前期制片决策工具。 |
| **必须进入专业合成（Nuke/Fusion）** | 所有含真人实拍底片、局部泡沫板扩展、高斯泼溅内舱结合、微缩模型实拍层叠加星空背景、数字角色（K-2SO/塔金）与实拍互动的镜头 [A级][B级]。 | 三维渲染器无法直接处理实拍底片的镜头呼吸畸变、光学晕染（Light Wrap）、胶片颗粒对齐及室内外真实曝光滚降。 |
| **必须实拍（或现场实体辅助）** | 1. 真人演员对手戏及数字角色的现场真人替身表演（必须现场对视、供摄影机真实框取）[A级]；<br>2. 大面积纯白平衡且实搭成本与虚拟差不多的走廊布景（如《坦蒂夫四号》走廊）[A级]；<br>3. 阳光海滩等真实自然强光下的飞船外景或微缩模型实拍 [B级]。 | 1. 缺真人现场互动会导致表演被劈成两半、摄影机失去真实微调反应 [A级]；<br>2. 纯白环境虚拟打光极难且不划算 [A级]。 |

---

## 六、 模块 E：合成任务标准描述（Compositing Task Specification）

每个提交给合成部门的镜头包（Shot Package）必须包含以下 17 个标准数据字段。任何字段的缺失都将触发管线阻断：

| 序号 | 标准字段名 | 核心用途说明 | 缺失后果（Failure Consequence） |
| :--- | :--- | :--- | :--- |
| 1 | `plate` | 现场摄影机拍摄的主底片（含演员表演、局部实体布景、现场真实受光）。 | 失去整个镜头的叙事载体、真实表演与物理光照基准 [A级]。 |
| 2 | `clean_plate` | 同一机位清场后拍摄的无演员/无威亚/无动捕替身的干净背景底片。 | 擦除现场穿动捕服的真人替身（如 Alan Tudyk）时无真实背景像素可填补，导致背景修补区域出现涂抹伪影 [A级]。 |
| 3 | `foreground` | 位于 CG 主体前方的实拍扣像层或前景遮挡元素层。 | 破坏画面前后空间纵深，CG 角色或飞船像贴纸一样浮在所有画面最上层。 |
| 4 | `background` | 远景环境层（数字星海、云层、高斯泼溅渲染出的内舱视角或扩展布景）。 | 蓝幕/泡沫板之外的区域无内容填充，无法完成场景扩展 [A级]。 |
| 5 | `cg_assets` | 包含完整多通道 AOV 的三维渲染序列（32-bit EXR）。 | 缺乏主特效视觉元素，或因缺少分通道（如 Glossy）导致无法在合成端微调金属反射质感 [B级]。 |
| 6 | `camera_tracking` | 3D 摄影机反求出的逐帧空间坐标、旋转曲线及现场点云（Point Cloud）。 | 对于手持抓拍镜头（如《侠盗一号》），CG 元素与实拍背景会发生致命的滑动脱节（Sliding）[A级]。 |
| 7 | `lens_data` | 拍摄镜头的焦距、光圈、焦点距离及镜头网格畸变图（Undistort/Redistort STMap）。 | CG 笔直的几何边缘无法匹配实拍光学镜头的桶形/枕形畸变与边缘色散，产生“数字硬边感”。 |
| 8 | `lighting_reference`| 现场灰球（Grey Ball）、铬球（Chrome Ball）及红外动捕下保留的原始面部受光参考底片 [A级]。 | 灯光与合成师盲目猜光，导致 CG 光向、软硬度及室内外曝光比与实拍完全割裂（如被白光 LED 毁掉参考）[A级]。 |
| 9 | `reflection_reference`| 现场全景环境图、或微缩模型在 LED 棚内拍摄到的真实动态反射参考 [A级][B级]。 | 裸金属飞船或头盔表面反射空洞、虚假，失去置身于复杂大气云层或霓虹街道中的物理说服力 [A级]。 |
| 10 | `shadow_pass` | CG 元素投射在实拍地面/泡沫板上的阴影通道及实拍物体投在 CG 上的遮蔽通道（AO/Contact Shadow）。 | 角色或停放的飞船产生“漂浮感”（Floating），无法与实拍地面建立物理重力接触。 |
| 11 | `depth_pass` | 归一化或真实世界米制单位的 Z-Depth 深度通道。 | 无法计算准确的光学景深模糊（Defocus）与大气雾效衰减（Z-Fog），远近层次扁平。 |
| 12 | `motion_vector` | 记录像素在帧与帧之间 X/Y 移动速度和方向的 2D 运动矢量通道。 | 快速移动的飞船或侧滚的生物缺乏与实拍快门速度一致的运动模糊，画面出现生硬的定格频闪感。 |
| 13 | `matte` | 包含手绘 Roto 遮罩、蓝绿幕抠像 Alpha 以及 CG 资产的 Cryptomatte 通道。 | 无法精确分离前景与背景，边缘出现蓝边溢色（Spill）、锯齿或半透明细节丢失。 |
| 14 | `color_management`| 色彩空间转换配置（如 ACEScg 工作空间、现场 Show LUT、CDL 调色参数）。 | 实拍底片的对数色彩（Log）与 CG 线性色彩（Linear）直接错误叠加，导致高光死白、暗部发灰、对比度崩塌。 |
| 15 | `grain` | 从实拍底片采样的各通道（R/G/B）真实感光元件噪点或胶片颗粒配置文件。 | CG 渲染层过于干净平滑，在动态播放时与实拍底片的颗粒沸腾感格格不入，瞬间暴露假象。 |
| 16 | `final_output` | 最终交付的母版格式规范（分辨率、帧率、画幅比——如原生 IMAX 画幅或标准宽银幕、色彩编码）[A级]。 | 无法正确回批至剪辑时间线或导致影院放映画幅裁切错误。 |

---

## 七、 模块 F：质量控制（Quality Control）清单

结合 Knoll 对技术精度与艺术记忆还原的双重标准，质检分为 **12 项技术检查** 与 **7 项艺术检查**，并明确界定机器自动化检测与人类专家（总监/摄影指导）判定的边界：

### 1. 技术检查 12 项（Technical QC）
| 序号 | 检查项名称 | 验收技术标准 | 判定方式 |
| :--- | :--- | :--- | :--- |
| T01 | **EXR 通道与元数据完整性** | 检查模块 E 规定的 16 项输入通道、帧范围、分辨率、帧率是否齐全无损。 | **机器可检**（Python 脚本自动校验） |
| T02 | **色彩空间与 LUT 一致性** | 检查所有输入输出是否严格挂载同一套 ACES/Show LUT 配置，无 Gamma 双重叠加。 | **机器可检**（OCIO 管线配置校验） |
| T03 | **NaN / Inf 坏点像素扫描** | 扫描高光反射区是否存在非数字（NaN）或无穷大（Inf）导致的黑斑/闪烁像素。 | **机器可检**（像素极值自动扫描脚本） |
| T04 | **画幅遮罩与 IMAX 边界合规** | 校验标准画幅与 45% 原生 IMAX 画幅镜头的安全框与边缘是否有穿帮未渲染区 [A级]。 | **机器可检**（边界 Alpha 与非零像素检测） |
| T05 | **摄影机跟踪滑动误差（Slippage）**| 检查手持抓拍镜头中 CG 接地位置与实拍特征点的像素偏移量（阈值需 < 0.5 像素）[A级]。 | **机器辅助 + 必须人判**（重投影误差值机检，视觉微颤人判） |
| T06 | **黑位与白点（Black/White Point）对齐**| 切换单通道（R/G/B）极端增益观察，CG 暗部最黑值不得低于实拍底片底噪黑位。 | **机器辅助 + 必须人判**（波形图/直方图机检，视觉融合人判） |
| T07 | **室内外曝光比合理性** | 检查棚内实拍室内景与合成窗外日景的曝光光圈差，严禁窗台被打爆且无自然光学滚降 [A级]。 | **必须人判**（由特效总监与 DP 联合审看）[A级] |
| T08 | **镜头畸变与色散匹配** | 检查 CG 边缘是否已正确应用实拍镜头的呼吸畸变（Redistort）及边缘微弱色差。 | **必须人判**（合成主管放大 400% 边缘复核） |
| T09 | **抠像边缘与溢色（Spill/Edge）** | 检查蓝幕/泡沫板交界处有无彩色镶边、硬切割感或半透明发丝闪烁。 | **必须人判**（逐帧正倒放检查） |
| T10 | **运动模糊矢量对齐** | 检查 CG 快速运动物体的模糊长度、方向及前后缘衰减是否与实拍快门一致。 | **必须人判**（单帧静帧比对） |
| T11 | **颗粒/噪点动态匹配** | 在放大视图下动态播放，检查 R/G/B 三通道颗粒大小与跳动频率是否与实拍无异。 | **必须人判**（单通道动态开关比对） |
| T12 | **实景与数字模型接缝吻合度** | 针对演员上下飞船等实景与 CG 交接镜头，检查舱门线与比例是否严丝合缝（防 U 翼式错位）[A级]。 | **必须人判**（总监级逐帧检视） |

### 2. 艺术检查 7 项（Artistic QC - 全部为【必须人判】）
艺术质检无法由算法代劳，必须由视觉特效总监、艺术指导（如 Yanick Dusseault 角色）与导演依据以下准则人工裁决 [A级/B级]：
1.  **观众记忆对齐度（Memory Alignment）**：资产与画面风格是否对齐了观众脑海中对经典美学的“记忆样子”，而非机械呆板地照搬粗糙的现实旧档案（"Match your memory of it more than the reality"）[A级]？
2.  **《传承风格册》工艺契合度（Legacy Style Book Compliance）**：数字飞船与场景扩展是否保留了手工微缩模型套件拼装（Kitbashing）的颗粒感与工艺价值，是否避免了过度光滑、均质化的廉价数字感 [A级]？
3.  **裸金属与复杂环境反射说服力**：高反光金属表面（如 Razor Crest 或头盔）的反射是否像汽车广告般兼具美感与环境真实感？穿过云层或霓虹街道时，动态反射与行星反光色是否正确交代了所处环境 [A级/B级]？
4.  **数字角色眼神与对手戏真实感**：数字角色（如 K-2SO、塔金、莱娅、Embo）与真人演员的视线交汇是否自然？摄影机的构图微调是否保留了现场对着真人替身拍摄时的鲜活呼吸感 [A级]？
5.  **生物运动物理重量感**：虚构生物（如 Rotta）的动作是否扎根于真实自然界生物的力学参照（如象海豹冲锋的笨重与猛烈感），有无人造动画的轻飘感 [A级]？
6.  **叙事空间清晰度**：大型合成建筑（如 Citadel 城堡）在复杂动作剪辑中，是否通过清晰的几何与同心圆模块化设计让观众明确感知地理跨越而不迷失方向 [B级]？
7.  **媒介无痕融合度（Medium Invisibility）**：微缩模型实拍、定格动画、高斯泼溅内舱与纯 CG 镜头混剪在一起时，是否达到了“几乎无法分辨哪一帧是模型、哪一帧是 CG”的浑然一体状态 [B级]？
