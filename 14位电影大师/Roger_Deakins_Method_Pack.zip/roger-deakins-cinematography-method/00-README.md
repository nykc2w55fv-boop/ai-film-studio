# Roger A. Deakins 摄影方法证据研究包

**包名**：`roger-deakins-cinematography-method`  
**专业类别**：`cinematography`  
**研究截止**：2026-11-06（本次检索访问日；不代表来源首发时间）  
**状态**：可供本地程序导入的**研究资料**，不是已安装的 Skill，也不是已生成的视频。  
**对象**：Roger A. Deakins（摄影指导）；动画工作以 visual consultant 另列。

## 读取与执行入口

- 先读取 `01-identity-and-credits.md` 确认身份/岗位，再读取 `02-source-registry.md` 检索 `source_id`。
- `04-film-case-studies.md` 记录逐场证据与归属；`09-method-cards.md` 提供人读方法；`10-methods.json` 是程序入口。
- `11-ai-adaptation.md` 是**本研究自行创造的 AI 工程适配**，**不是** Deakins 实际采用 AI 的史实。
- `12-role-handoff.md` 规定摄影视角的输入、交付与审批；`14-validation-plan.md` 是待执行测试，未生成成片或取得真实观众评分。
- 所有方法都引用 `source_id`；证据等级见来源注册表。不可从方法代号直接推断作者创造了某条独特理论。

## 关键成果

- 登记资料 **32** 项（并非每项都核验全文），含官方作品目录、ASC现场采访、本人署名论坛答复、其他直接参与者陈述；其中部分资料仅能访问索引或摘要，标明限制。
- 案例 **24** 个：其中 **19** 个核心深入拆解、**5** 个辅助/跨类型/动画案例。
- 可执行摄影方法卡 **11** 张，均有来源、适用条件、失效点、AI适配及可测试输出。
- 不伪造时间码、个人摄影师名言、AI控制参数。没有在本轮逐帧观看完整影片，也未获得《Reflections》全文，因此不以书中未读章节支持镜头细节。

## 归纳结论（证据边界）

1. **先弄清故事再选择摄影**。Roger谈第一次读剧本时先评估故事如何触动自己，而非立即定镜头；之后和导演沟通场景/排期。[S002](https://studentfilmmakers.com/cinematograter-roger-deakins-asc-bsc/)。
2. **空间与灯光应当一起设计**。《囚徒》改选加油站附近停车场、《边境杀手》搭建棚景、《银翼杀手2049》灯光与建筑同构均有第一手资料。[S011](https://theasc.com/article/beyond-the-law-prisoners/)、[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)、[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)。
3. **运动不是越少越好**。1997年他说《冰血暴》的“基本不移动”原则在开拍第二镜就被打破；《1917》则以角色跟随和观看关系组织复杂移动。[S004](https://www.latimes.com/archives/la-xpm-1997-03-23-ca-41081-story.html)、[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)。
4. **后期不是不存在**。本人谈尽量现场建立效果；但《银翼杀手2049》有完整调色流程，《1917》火场含CG替代，《缺席的人》曾采用彩色拍摄再转黑白。[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)、[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)、[S006](https://www.latimes.com/archives/la-xpm-2001-oct-28-ca-62479-story.html)。
5. **成果不是单人创作**。导演决定叙事目标、production designer 决定空间/材质条件，摄制灯光团队实现方案，James Ellis Deakins 参与创作协调及数字流程。[S022](https://teamdeakins.libsyn.com/turning-the-tables-our-partnership)、[S023](https://athenaeumcenter.org/performers/james-ellis-deakins/)。

## 术语和等级

- **已知事实**：可由署名人陈述、官方作品目录或可靠直接参与者材料证实的具体制作决定。
- **标准领域知识**：普通光学/摄影/三维制作知识，不暗示出自Deakins。
- **推论**：从多个实例构建的调用流程和检查机制。
- **框架内说法，连贯不等于真实**：method_id、路由表、验收评分是研究者创建的工作框架。
- **无法确定**：未查到的镜头具体数值、时间码或个人归属，不以估测填充。

**导入注意**：先校验 `10-methods.json`，方法引用来源必须在 `02-source-registry.md` 中存在，发生冲突时遵照 `15-evidence-audit.md` 优先保留直接史实。版权画面不随包复制。
