# 身份、署名和职责核实

## 1. 身份与职业阶段

Roger A. Deakins，英国电影摄影指导，官网署名 CBE、ASC、BSC。早期从纪录片摄影进入电影行业，后参与英国故事片；1991年《巴顿·芬克》与科恩兄弟合作，之后与 Sam Mendes、Denis Villeneuve 长期合作。参见 [S001](https://www.rogerdeakins.com/filmography/)、[S005](https://thereveal.film/interview-roger-and-james-deakins-on-cinematography-and-navigating-a-changing-film-world/)。

## 2. 研究电影与摄影署名

| 年份 | 影片 | 本包身份 | 署名来源 |
|---:|---|---|---|
|1994|The Shawshank Redemption|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|1996|Fargo|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2001|The Man Who Wasn’t There|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2007|No Country for Old Men|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2007|The Assassination of Jesse James by the Coward Robert Ford|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2012|Skyfall|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2013|Prisoners|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2015|Sicario|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2017|Blade Runner 2049|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2019|1917|摄影指导|[S001](https://www.rogerdeakins.com/filmography/)|
|2022|Empire of Light|摄影指导|[S017](https://theasc.com/article/empire-of-light-deakins/)|
|2008|WALL•E|视觉顾问|[S001](https://www.rogerdeakins.com/filmography/)|
|2010|How to Train Your Dragon|视觉顾问|[S001](https://www.rogerdeakins.com/filmography/)|
|2014|How to Train Your Dragon 2|视觉顾问|[S001](https://www.rogerdeakins.com/filmography/)|
|2019|How to Train Your Dragon: The Hidden World|视觉顾问|[S001](https://www.rogerdeakins.com/filmography/)|

**核实说明**：官网片目只列到 2019 年附近，不以其缺项断言狄金斯此后没有作品；2022年《帝国之光》由ASC独立核实。早年参与纪录片、合拍、第二组工作的性质不能简单当作剧情长片正片摄影；特别是官网把《The Reader》(2008)列为与 Chris Menges 共同摄影，不应写成独立单人署名。

## 3. 合作与决策归属

| 工作环节 | 典型资料/人物 | 本研究的归属原则 |
|---|---|---|
|导演|Coen brothers、Sam Mendes、Denis Villeneuve|例如《1917》沉浸式单镜体验的初始要求来自Mendes；《边境杀手》直升机地理机位来自Villeneuve的场地限制选择。参见S016、S013|
|摄影指导|Roger Deakins|统筹构图、观看关系、光线、机位建议与现场摄影；只有受访者证明确属他提案时才写“Roger提出”|
|美术指导|Terence Marsh（《肖申克》）、Patrice Vermette（《边境杀手》）、Dennis Gassner（《2049》《1917》）|建筑、外形、材质、可变墙体、道具光源；与摄影协商不是被摄影单向“执行”|
|灯光/机械/摄影机组|John “Biggles” Higgins、Chris Napolitano、Billy O’Leary、Pete Cavaciuti 等|Rig、配光、摄影机稳定装置、走位的具体实施和创造应保留实施者姓名；不同影片班底不同|
|调色/数字工作流|Mitch Paulson、数字成像团队、James Ellis Deakins|最终影调与多版本交付是后期协作结果；不能将所有画面颜色归现场灯光|
|VFX /合成|具体项目VFX团队、模型和动画团队|CG火焰、全息人像和延伸空间属于单独贡献，摄影主要协调现场光和拍摄素材|

## 4. James Ellis Deakins（不能误译为另一位男性摄影指导）

James Ellis Deakins 是 Roger 的长期工作和生活伴侣，曾从事实验室技术及场记工作；在数字工作流程、制作计划、跨部门问题解决方面深度参与。2024年播客由Rick Carter提问，Roger谈信任James让他可以同时处理多地事务；ASC《The Goldfinch/1917》明确称James担任数字流程顾问并在访谈提供技术细节。**不要将她署名为《1917》正片摄影指导**，也不要把共同创作规划等同个人灯光实际执行。来源 S016、S022、S023、S005。

## 5. 动画视觉顾问不是摄影指导

官网明确为《WALL•E》《驯龙高手》及续集等标注 `Visual Consultant`。DeBlois直接解释动画layout、分镜、lighting生产常相距很久，Deakins帮助协调光影与镜头目标。真人摄影指导通常组织实拍摄影部门；动画顾问并不等同直接操作动画摄影机/渲染器，也不能认定其设计了影片所有镜头。来源S001、S024。对于《WALL•E》具体建议内容，本轮仅能核实署名，**无法确定**具体镜头贡献。
