# 来源注册表与检索协议

检索访问日期：2026-11-06。**等级A指第一手可核实发言/官方署名、B指直接制作人叙述或机构资料、C指有线索的间接转载、D不承载正式结论**；一条网页不意味着其中每句话都属于同一位发言人。下列“支持内容”仅是研究摘述，不是直引。

## S001 · Roger A. Deakins – Filmography

- 涉及案例：C24（How to Train Your Dragon: The Hidden World/动画隐秘世界的空间/光关系）
- 作者/发言者：Roger A. Deakins / 官方网站
- 发布：日期无法确定；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://www.rogerdeakins.com/filmography/
- 可证明：官网电影目录；区分 Visual Consultant；目录不完全及时
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S002 · A Conversation with Roger Deakins, ASC, BSC

- 涉及案例：C07（The Assassination of Jesse James by the Coward Robert Ford/影片叙述性过渡/记忆质感镜头）
- 作者/发言者：Jacqueline B. Frost / Roger Deakins
- 发布：日期无法确定；访问：2026-11-06
- 等级：**A**；可用性：公开可读；网页未显示可靠首次发表日期
- 原始链接：https://studentfilmmakers.com/cinematograter-roger-deakins-asc-bsc/
- 可证明：本人说明第一次读剧本先感受故事；拆解场景、排期、与导演沟通；测试依项目而异
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S003 · Photographing The Shawshank Redemption

- 涉及案例：C01（The Shawshank Redemption/新囚犯入监与狱长讲话）, C02（The Shawshank Redemption/安迪逃脱下水通道）
- 作者/发言者：Christopher Probst / Roger Deakins、Frank Darabont与摄影团队
- 发布：1995-06 / 2017-08-23转载；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/article/flashback-the-shawshank-redemption/
- 可证明：监狱墙体灰度测试、光源伪装、建筑压迫、逃生隧道手电；原文刊1995-06
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S004 · They Get the Picture: Roger Deakins on Fargo

- 涉及案例：C03（Fargo/Jerry返回空旷停车场）, C04（Fargo/雪地调查/全片外景原则）
- 作者/发言者：Los Angeles Times / Roger Deakins
- 发布：1997-03-23；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://www.latimes.com/archives/la-xpm-1997-03-23-ca-41081-story.html
- 可证明：《冰血暴》雪不足、补雪；原拟少移动机位但执行时调整
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S005 · Interview: Roger and James Deakins on Cinematography and Navigating a Changing Film World

- 涉及案例：C03（Fargo/Jerry返回空旷停车场）
- 作者/发言者：Keith Phipps / Roger & James Deakins
- 发布：2025-12-10；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://thereveal.film/interview-roger-and-james-deakins-on-cinematography-and-navigating-a-changing-film-world/
- 可证明：Fargo空停车场改变原分镜；合作；技术不应喧宾夺主；来源不能代替已出版书全文
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S006 · Framing Small Moments

- 涉及案例：C05（The Man Who Wasn’t There/全片黑白视觉系统）
- 作者/发言者：Los Angeles Times / Ethan Coen、Roger Deakins
- 发布：2001-10-28；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://www.latimes.com/archives/la-xpm-2001-oct-28-ca-62479-story.html
- 可证明：《缺席的人》彩色负片拍摄后黑白发行；光的形状和黑白意图；科恩负责黑白方向
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S007 · Roger Deakins on No Country for Old Men

- 涉及案例：C06（No Country for Old Men/暴力事件的摄影总体原则）
- 作者/发言者：Rotten Tomatoes / Roger Deakins
- 发布：日期无法确定；访问：2026-11-06
- 等级：**A**；可用性：公开可读；页面可能回溯改版
- 原始链接：https://editorial.rottentomatoes.com/article/rt-interview-roger-deakins-on-no-country-for-old-men/
- 可证明：科恩希望不煽情、不弱化暴力；故事板与机位
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S008 · Masterclass: Sir Roger Deakins

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：British Cinematographer / Roger Deakins
- 发布：日期无法确定；访问：2026-11-06
- 等级：**B**；可用性：搜索摘要可见，全文访问受限
- 原始链接：https://britishcinematographer.co.uk/exclusive-masterclass-sir-roger-deakins-cbe-bsc-asc/
- 可证明：可见搜索摘录提及《老无所依》Moss返回峡谷场景；全文受403阻断，仅作有限辅助，不承载关键细节
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S009 · Shot Craft: Lens Test — The Deakinizer

- 涉及案例：C07（The Assassination of Jesse James by the Coward Robert Ford/影片叙述性过渡/记忆质感镜头）
- 作者/发言者：Jay Holben、Kaity Williams / American Cinematographer
- 发布：日期无法确定；访问：2026-11-06
- 等级：**B**；可用性：公开可读
- 原始链接：https://theasc.com/article/shot-craft-lens-test-the-deakinizer/
- 可证明：《神枪手之死》为早期摄影质感定制镜头；测试为后续摄影师的复测，不等于原始影片参数
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S010 · Skyfall: MI6 Under Siege

- 涉及案例：C08（Skyfall/上海写字楼玻璃隔间与电子广告）, C09（Skyfall/苏格兰庄园夜间直升机与火灾）
- 作者/发言者：American Cinematographer / Roger Deakins、John Higgins等
- 发布：2012-12原刊 / 网站更新日未核实；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/article/skyfall-mi6-under-siege/
- 可证明：上海LED广告牌玻璃场景；庄园直升机探照灯、火光；调色和VFX分工
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S011 · Beyond the Law: Prisoners

- 涉及案例：C10（Prisoners/雨夜房车与加油站停车场）, C11（Prisoners/Loki感恩节独坐餐馆）, C12（Prisoners/结尾户外隐蔽地窖与警察撤离）
- 作者/发言者：American Cinematographer / Roger Deakins、Chris Napolitano等
- 发布：2013-10原刊 / 网页后转载；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/article/beyond-the-law-prisoners/
- 可证明：RV加油站夜景、洛基餐馆、结尾警灯工地、克制的摄影机
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S012 · Roger Deakins: Lighting Sicario

- 涉及案例：C13（Sicario/开场破门突袭的室内场景）, C15（Sicario/Kate在屋顶黄昏远眺Juárez）, C16（Sicario/移民收容区大型夜景）
- 作者/发言者：Benjamin B / Roger Deakins
- 发布：2015-10-16；访问：2026-11-06
- 等级：**A**；可用性：公开可读；配图为出版原图，未再制作为图
- 原始链接：https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/
- 可证明：入室突袭棚景与透视、T12及布光图、屋顶黄昏、移民收容区灯具、DI
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S013 · Sicario: Interview with Denis Villeneuve

- 涉及案例：C14（Sicario/美墨边境车队与直升机镜头）
- 作者/发言者：American Cinematographer / Denis Villeneuve
- 发布：2015；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/post/the-film-book/sicario-interview-with-denis-villeneuve/
- 可证明：边境高空镜头由桥上拍摄许可限制与空间叙事共同推动；该决定归导演
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S014 · Uncanny Valley: Blade Runner 2049

- 涉及案例：C17（Blade Runner 2049/Wallace总部办公室两场对话）, C18（Blade Runner 2049/K与Luv走过复制人博物馆楼梯与走廊）, C19（Blade Runner 2049/废弃赌场中K与Deckard遭遇）
- 作者/发言者：Rachael Bosley / Roger Deakins及电影团队
- 发布：2017-12原刊 / 2018-03-06网页；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/article/uncanny-valley-blade-runner-2049/
- 可证明：Wallace办公室移动光、水面焦散；博物馆走廊；赌场灯光预演；后期调色交接
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S015 · Roger Deakins at Clubhouse for Blade Runner 2049 Discussion

- 涉及案例：C17（Blade Runner 2049/Wallace总部办公室两场对话）
- 作者/发言者：ASC staff / Roger Deakins
- 发布：2017-11左右（确日未核）；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/news/roger-deakins-at-clubhouse-for-blade-runner-2049-discussion/
- 可证明：建筑塑造剪影；能在演员临场变化时调整分镜；尽量现场得到颜色和实际拍摄
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S016 · Lives Under Siege: The Goldfinch and 1917

- 涉及案例：C20（1917/战壕连续跟拍）, C21（1917/地堡获得命令、进入黑暗通道）, C22（1917/夜间燃烧教堂与村庄）
- 作者/发言者：American Cinematographer / Roger & James Deakins
- 发布：2020（确日未核）；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/
- 可证明：1917片段路线、排练定景、Stabileye等拍法、天气匹配、照明、火场VFX
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S017 · Empire of Light: Theater of Dreams

- 涉及案例：C23（Empire of Light/电影院售票窗及大厅中的Hilary）
- 作者/发言者：Mark Dillon / Roger Deakins、Sam Mendes
- 发布：2023-01-16；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://theasc.com/article/empire-of-light-deakins/
- 可证明：摄影与主角孤独空间关系、现场摄影流程、灯位图与手持/轨道取舍
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S018 · Lighting (Roger Deakins forum reply)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger Deakins，论坛账号署名
- 发布：2023-06-27主题 / 2023回复（确日未核）；访问：2026-11-06
- 等级：**A**；可用性：公开可读；仅使用署名Roger Deakins的回复
- 原始链接：https://www.rogerdeakins.com/forums/topic/lighting/
- 可证明：质量→光圈→成本；《坚不可摧》餐馆受空间限制改反射光；DI不总是重大改变
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S019 · Lighting Trends (Roger Deakins forum reply)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger Deakins，论坛账号署名
- 发布：2023-09-17主题；访问：2026-11-06
- 等级：**A**；可用性：公开可读；排除其他用户观点
- 原始链接：https://www.rogerdeakins.com/forums/topic/lighting-trends/
- 可证明：允许非完全写实的光，但要在片中自然成立
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S020 · Focal Lengths (Roger Deakins forum reply)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger Deakins，论坛账号署名
- 发布：2023-05-13主题；访问：2026-11-06
- 等级：**A**；可用性：公开可读；只保留本人回复
- 原始链接：https://www.rogerdeakins.com/forums/topic/focal-lengths/
- 可证明：焦距随景别、画幅和任务变化；不能固化32mm
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S021 · Multiple lights / batten lights (forum reply)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger Deakins，论坛账号署名
- 发布：2024左右（确日未核）；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://www.rogerdeakins.com/forums/topic/multiple-lights-batten-lights-elongated-sources-array-of-individual-fixtures/
- 可证明：阵列灯影子根据距离和拍摄对象需另行测试；不能机械套用
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S022 · Turning the Tables: Our Partnership

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Team Deakins / Roger & James Deakins / guest Rick Carter
- 发布：2024-09-04；访问：2026-11-06
- 等级：**A**；可用性：简介公开可读；未逐字转录音频
- 原始链接：https://teamdeakins.libsyn.com/turning-the-tables-our-partnership
- 可证明：James解决多部门问题，Roger信任James协助分身协调；是播客摘要非全本逐字稿
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S023 · James Ellis Deakins biography

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Athenaeum Center
- 发布：日期无法确定；访问：2026-11-06
- 等级：**B**；可用性：公开可读；机构简介
- 原始链接：https://athenaeumcenter.org/performers/james-ellis-deakins/
- 可证明：James先后任实验室技术员、场记、数字工作流协作，项目规划与协调
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S024 · How to Train Your Dragon: The Hidden World / Dean DeBlois interview

- 涉及案例：C24（How to Train Your Dragon: The Hidden World/动画隐秘世界的空间/光关系）
- 作者/发言者：Jennifer Vineyard / Dean DeBlois
- 发布：2020-01-08；访问：2026-11-06
- 等级：**A**；可用性：公开可读；导演本人为第一手
- 原始链接：https://www.syfy.com/syfy-wire/awards-contenders-legend-roger-deakins-played-a-huge-role-in-the-how-to-train-your-dragon
- 可证明：导演说明动画layout/lighting间沟通、Roger提供参考、审视运镜必要性
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S025 · How to Train Your Dragon: The Hidden World director interview

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Angela Dawson / Dean DeBlois
- 发布：2019-02-17；访问：2026-11-06
- 等级：**B**；可用性：可能重定向/未核对路径
- 原始链接：https://frontrowfeatures.com/features-category-of-interviews-and-spotlights/film-features/exclusive-filmmaker-dean-deblois-takes-a-colorful-and-emotional-ride-with-how-to-train-your-dragon-finale-25534.html
- 可证明：该链接路径需复核；仅作信息补充，不独立支撑方法
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S026 · Reflections: On Cinematography (publisher catalog)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Grand Central Publishing / Roger Deakins
- 发布：2025-11-11；访问：2026-11-06
- 等级：**B**；可用性：目录公开可读；正文未取得
- 原始链接：https://www.hachettebookgroup.com/titles/sir-roger-deakins/reflections/9781538771501/
- 可证明：书籍存在、416页和出版信息；书内场景图和细节未逐页阅读，绝不引用为已阅证据
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S027 · Reflections (official page)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger Deakins 官方网站 James
- 发布：2025-04-18；访问：2026-11-06
- 等级：**A**；可用性：公开可读；非书全文
- 原始链接：https://www.rogerdeakins.com/reflections/
- 可证明：书籍有图表、故事板等；没有核实书内具体页码
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S028 · Team Deakins podcast archive

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger & James Deakins
- 发布：日期无法确定；访问：2026-11-06
- 等级：**A**；可用性：公开索引
- 原始链接：https://teamdeakins.libsyn.com/
- 可证明：核实主持人与嘉宾身份；本包未听取全部音频，不推导具体技术
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S029 · Modern Times: AC Since 2010

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：American Cinematographer / Roger Deakins
- 发布：2020左右；访问：2026-11-06
- 等级：**B**；可用性：公开可读
- 原始链接：https://theasc.com/article/modern-times-ac-since-2010/
- 可证明：Alexa与胶片是本人针对当时设备的评价，不等于所有当代机器都成立
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S030 · Interview: Roger Deakins | Film Comment

- 涉及案例：C06（No Country for Old Men/暴力事件的摄影总体原则）
- 作者/发言者：Film Comment / Roger Deakins
- 发布：2014左右；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://www.filmcomment.com/interview-roger-deakins/
- 可证明：承认简单镜头也会想不出来；《大地惊雷》《老无所依》夜景的低照度困难
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S031 · Roger Deakins on The Man Who Wasn’t There (2001 interview)

- 涉及案例：C05（The Man Who Wasn’t There/全片黑白视觉系统）
- 作者/发言者：Roger Deakins / reproducing host
- 发布：2001左右；访问：2026-11-06
- 等级：**C**；可用性：二手转载；不独立支撑重要方法
- 原始链接：https://rogerdeakins.weebly.com/deakins-interview.html
- 可证明：转存本人访谈，出处/编辑完整性无法核实，仅与LA Times交叉辅助
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## S032 · Lighting Notes (forum)

- 涉及案例：职业/技术背景或资料身份核查
- 作者/发言者：Roger Deakins 官方论坛
- 发布：日期无法确定；访问：2026-11-06
- 等级：**A**；可用性：公开可读
- 原始链接：https://www.rogerdeakins.com/forums/topic/lighting-notes/
- 可证明：Roger对《Reflections》含光图但非技术手册的解释；注意个人留言与本人回复
- 不确定性：此条只支持上面点名内容；后续方法是研究综合推论；论坛必须辨认回复署名，新闻须分离记者概述和受访者发言。

## 特别排除

- 未经确认账号身份的网友推断或视频教程不作为Deakins原始方法。
- 《Reflections》（2025）**已确认出版**但本轮未取得全文，故不宣称已经核对书内页码或图示；其直接价值是将来进行页码级复核。
- `S008` 网站403；只可保留搜索摘要中可确认的“有此案例”，不得从摘要补灯具配置。
- 报道中用户/采访者的提问不等于Roger确认技术细节；对不确定灯具、曝光值一律不补全。
