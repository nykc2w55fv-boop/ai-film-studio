# 可执行方法卡：供AI影视总导演路由

**关键边界**：这里的步骤、触发规则、检验阈值是**本研究根据已证实案例构建的工程规则**。原始电影摄影习惯不等于Roger亲笔写了这些method_id。来源ID在02可查；对应电影场景ID在04可查。

## M01 · 从剧本的信息任务确定视觉优先级 / `story_first_visual_brief`

- **problem / 问题**：脚本无法直接指向摄影选择
- **trigger / 调用条件**：人物信息、空间叙事、情绪变化尚未转为摄影任务
- **prerequisites / 前提**：有场景剧本、导演意图或可标记的未知项
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 标记观众必须知道/暂时不能知道的事实
  2. 与导演确认主角视点及环境是否承担叙事
  3. 写出镜头必须交代的三项信息并按优先级排序
  4. 比较至少两个机位草案并说明失去什么信息
  5. 决定先保留关键人物与空间的可读性
- **decision_rules / 判断**：若只有“漂亮/高级”等形容词则退回重写叙事任务; 若导演未确定视点，先提出选项不得指定唯一机位
- **outputs / 交付**：scene_visual_brief, attention_targets, camera_intention, open_questions
- **evidence**：[S002](https://studentfilmmakers.com/cinematograter-roger-deakins-asc-bsc/)；[S003](https://theasc.com/article/flashback-the-shawshank-redemption/)；[S007](https://editorial.rottentomatoes.com/article/rt-interview-roger-deakins-on-no-country-for-old-men/)；[S017](https://theasc.com/article/empire-of-light-deakins/)
- **examples**：C01, C06, C23
- **limitations**：不是Roger独创的算法，是基于多项目对其流程的工程归纳
- **failure_modes**：空镜好看但角色动机不可读; 以摄影替代导演决定故事立场
- **validation**：遮挡角色台词测试：不看对白能否识别行动因果？; 把机位建议与剧本信息逐条对齐
- **ai_adaptation（工程推论）**：先产出结构化story_beats→attention_targets，不直接生成“狄金斯风格”
- **evidence_status**：推论（基于本人剧本/导演协作一手资料）；独创性标识：**不是作者专有定律**。

## M02 · 先确定可信的动机光与光源行为 / `motivated_source_map`

- **problem / 问题**：夜景/室内为可看而布置了不可信灯光
- **trigger / 调用条件**：场景中有明确光源或可通过勘景/美术补出可信光源
- **prerequisites / 前提**：空间图、昼夜、可见实用灯、人物路径
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 列出画内/画外可信光源与入射方向
  2. 按故事必须看见的物体分配最少照明区
  3. 对每个光源定义静态/运动/闪烁行为和触发事件
  4. 仅在主体信息不足时给非画内补光提出合理解释
  5. 在角色移动全过程预检遮挡与曝光可读性
- **decision_rules / 判断**：不能解释光从何来则调整地点/道具/设计，而非无限添加光; 光源过多导致互相矛盾时删除不必要者
- **outputs / 交付**：source_map, lighting_cues, visibility_risk_log
- **evidence**：[S010](https://theasc.com/article/skyfall-mi6-under-siege/)；[S011](https://theasc.com/article/beyond-the-law-prisoners/)；[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)；[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)；[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)；[S018](https://www.rogerdeakins.com/forums/topic/lighting/)
- **examples**：C08, C10, C12, C17, C22
- **limitations**：“自然可信”不等于一定柔光或单主光; 只有现成光源有时无法拍清人物
- **failure_modes**：影子方向互相冲突; 剪影吞掉必须识别的人脸; 虚拟光源随镜头移动而漂移
- **validation**：灰阶预览主体最低可读性; 核查每束主光对布景或道具的因果来源
- **ai_adaptation（工程推论）**：AI图像中定义一主光+环境/反射的关系；视频中分别锚定光源的世界坐标和时变状态
- **evidence_status**：推论（事实支持动机光做法，程序为工程抽象）；独创性标识：**不是作者专有定律**。

## M03 · 先用勘景改变构图与布光条件 / `location_as_lighting_design`

- **problem / 问题**：既有场地无法给出需要的视点或可信光源
- **trigger / 调用条件**：可勘景或可修改三维空间、道具
- **prerequisites / 前提**：位置备选、窗口朝向、开放角度、角色走位
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 确定观众必须看见的空间方向
  2. 分析每个备选地点能否自然形成光源层次
  3. 判断现场能否改造门窗/墙色/陈设
  4. 对比摄影复杂度和美术改造成本
  5. 提交场景/机位共同选择方案
- **decision_rules / 判断**：地点无法支持叙事信息时先改地点而非叠灯; 若美术/导演无权修改需升级冲突
- **outputs / 交付**：location_decision_sheet, set_change_requests
- **evidence**：[S003](https://theasc.com/article/flashback-the-shawshank-redemption/)；[S005](https://thereveal.film/interview-roger-and-james-deakins-on-cinematography-and-navigating-a-changing-film-world/)；[S011](https://theasc.com/article/beyond-the-law-prisoners/)；[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)；[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)
- **examples**：C01, C03, C10, C11, C13
- **limitations**：不是所有影片有条件换景；AI环境也可能受场景资产限制
- **failure_modes**：只给艺术指导一张精美参考却没有窗口/机位关系
- **validation**：场景图上标出机位、角色、主要光路; 宽景与近景均能使用预定光源
- **ai_adaptation（工程推论）**：Blender先完成白模与灯光草案，再生成高成本材质/建筑细节
- **evidence_status**：推论（有多场景一手直接做法）；独创性标识：**不是作者专有定律**。

## M04 · 让有限可见光服务必要信息 / `selective_visibility`

- **problem / 问题**：夜景光线太满或剪影吞掉必要叙事
- **trigger / 调用条件**：有受众需要识别的最低信息集合
- **prerequisites / 前提**：人物关键动作、暗区道具、镜头关系、光源
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 划分必看/可以模糊/必须暂时隐藏三区
  2. 将可见灯、门窗、手电与可追踪动作绑定
  3. 从宽镜切近镜时核查明暗含义一致
  4. 对不可见关键动作设计可察觉的局部光变化
  5. 若遮挡改变人物可读性则重测机位
- **decision_rules / 判断**：所谓“黑”可隐藏背景，但不能隐藏故事要求的事实; 不为视觉整齐而牺牲身份辨认
- **outputs / 交付**：visibility_map, silhouette_fallback
- **evidence**：[S003](https://theasc.com/article/flashback-the-shawshank-redemption/)；[S010](https://theasc.com/article/skyfall-mi6-under-siege/)；[S011](https://theasc.com/article/beyond-the-law-prisoners/)；[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)；[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)
- **examples**：C02, C08, C10, C21
- **limitations**：不适于对白表情依赖强且没有替代信息源的戏
- **failure_modes**：生成画面只有人形轮廓、角色身份失真; 画外线索缺失
- **validation**：盲看测试：能描述谁在哪里做什么; 分镜重要信息覆盖率>=90%为工程暂定阈值，非Roger标准
- **ai_adaptation（工程推论）**：AI每镜应明示哪些细节必须可见，不要求全域提亮
- **evidence_status**：推论；独创性标识：**不是作者专有定律**。

## M05 · 把自然条件写入拍摄顺序 / `natural_light_schedule`

- **problem / 问题**：天气、日落和云层导致镜头间差异
- **trigger / 调用条件**：存在日程与镜头可排序权
- **prerequisites / 前提**：日照窗口、镜头表、天气与一致性约束
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 标记每镜依赖的自然条件
  2. 优先拍最受日光方向限制的镜头
  3. 预排多机位路线和转换耗时
  4. 天气不符时转排练或不依赖自然光镜头
  5. 用参考帧检查剪接时亮度/阴影方向
- **decision_rules / 判断**：条件窗口不确定时必须有保底方案; 不将个案40分钟视为普遍黄金时段
- **outputs / 交付**：light_window_plan, weather_fallback, continuity_reference
- **evidence**：[S004](https://www.latimes.com/archives/la-xpm-1997-03-23-ca-41081-story.html)；[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)；[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)
- **examples**：C04, C15, C20
- **limitations**：AI视频工作流的“天气”对应场景一致性随机性，不是物理真实云层
- **failure_modes**：为赶进度混用四种阳光方向
- **validation**：统一序列截图并作光向对照; 每个连续镜头标签完整
- **ai_adaptation（工程推论）**：固定场景的天气、太阳方位和时段文本资产；不能保证生成器完全遵守
- **evidence_status**：推论；独创性标识：**不是作者专有定律**。

## M06 · 摄影机运动必须解释信息变化 / `movement_requires_information`

- **problem / 问题**：运动镜头炫技或固定镜头妨碍人物信息
- **trigger / 调用条件**：明确人物行动和观看目的
- **prerequisites / 前提**：beat_sheet、空间图、人物路径
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 先做静机位版本，看是否足以交代动作
  2. 为每次运动写出新增信息或人物关系变化
  3. 确认运动不会强迫表演适应机械路径
  4. 连续镜头优先规划反应信息可见窗口
  5. 若移动后信息并未增量则简化或删除
- **decision_rules / 判断**：信息增量为空且无明确情绪目的→固定机位; 过多转场破坏空间理解→分镜重构
- **outputs / 交付**：camera_motion_rationale, shot_path_option
- **evidence**：[S004](https://www.latimes.com/archives/la-xpm-1997-03-23-ca-41081-story.html)；[S007](https://editorial.rottentomatoes.com/article/rt-interview-roger-deakins-on-no-country-for-old-men/)；[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)；[S024](https://www.syfy.com/syfy-wire/awards-contenders-legend-roger-deakins-played-a-huge-role-in-the-how-to-train-your-dragon)
- **examples**：C04, C06, C20, C24
- **limitations**：不能从《冰血暴》推出禁止移动；不能从《1917》推出总要运动
- **failure_modes**：摄像机扫景但忘记人物; 机器运动轨迹与人物冲突
- **validation**：每次运动都能回答“前后观众知道什么不同”
- **ai_adaptation（工程推论）**：视频生成仅发一项运动主命令；复杂长镜头拆片段、Blender按曲线路径预演
- **evidence_status**：推论（跨案例归纳）；独创性标识：**不是作者专有定律**。

## M07 · 视觉工艺以任务测试而非固定滤镜 / `test_medium_not_preset`

- **problem / 问题**：黑白、旧照片或低对比效果被误写成万能LUT
- **trigger / 调用条件**：可做样片/色彩测试
- **prerequisites / 前提**：预期影调、角色肤色、环境、目标媒介
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 先指定叙事上为何需要黑白/旧镜头质感
  2. 比较至少两种现场或后期路径
  3. 保留信息与光学副作用的测试记录
  4. 区分现场成像、冲印/DI、终端显示差异
  5. 输出只针对当前作品的审美/技术决定
- **decision_rules / 判断**：样片失效则不推广参数; 未经实测的镜头数字必须留空
- **outputs / 交付**：image_test_protocol, medium_choice_log
- **evidence**：[S006](https://www.latimes.com/archives/la-xpm-2001-oct-28-ca-62479-story.html)；[S009](https://theasc.com/article/shot-craft-lens-test-the-deakinizer/)；[S018](https://www.rogerdeakins.com/forums/topic/lighting/)；[S029](https://theasc.com/article/modern-times-ac-since-2010/)
- **examples**：C05, C07
- **limitations**：仿旧镜头是某片具体决定，不能当个人通用风格
- **failure_modes**：套滤镜导致肤色和细节损失; 把显示器差异误判成原片曝光
- **validation**：制作对照帧、检测信息可辨认; 把后期来源逐项标记
- **ai_adaptation（工程推论）**：AI可定义视觉范围与禁忌，但不预置“狄金斯LUT”；Blender做镜头材质/后期测试
- **evidence_status**：推论；独创性标识：**不是作者专有定律**。

## M08 · 长镜头/复杂场景先排信息—走位—光—空间 / `choreograph_before_build`

- **problem / 问题**：运镜路径与景长、灯位、角色节奏互相冲突
- **trigger / 调用条件**：导演同意走位，能够进行白模预演
- **prerequisites / 前提**：人物走位、剧情节拍、场景尺寸、光源变化
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 按表演节奏排角色关键位置时间
  2. 逐段选择机位面对/背向角色及反应可见性
  3. 反推场景几何、摄影机通道、器材隐蔽区
  4. 与灯光设计时变状态和隐藏切换/衔接点
  5. 无灯光/空间可行性时调整路径并重新排练
- **decision_rules / 判断**：连续摄影不得以观众错过关键人物反应为代价; 超出预算/可控性时优先拆解并通过剪辑保留连续体验
- **outputs / 交付**：timeline_blocking, camera_path, lighting_cue_timeline, handoff_points
- **evidence**：[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)；[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)；[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)
- **examples**：C13, C16, C19, C20, C21, C22
- **limitations**：1917是特殊任务，不是适用于全部电影的固定语法
- **failure_modes**：穿墙、瞬间转向、时间线无法对齐; 演员站位不符合镜头路径
- **validation**：白模可全程播放且能识别全部关键动作; 每个节点无碰撞/穿模
- **ai_adaptation（工程推论）**：Blender做轨迹预演；AI视频分镜头生成并通过遮挡或cut点接续，保留失败标识
- **evidence_status**：推论（多项目直接证据）；独创性标识：**不是作者专有定律**。

## M09 · 摄影—美术—后期共同管理视觉系统 / `integrated_visual_ownership`

- **problem / 问题**：每个镜头独立完美但整部影片光色不一致
- **trigger / 调用条件**：跨专业能共享场景信息
- **prerequisites / 前提**：美术色卡、材质、摄影曝光原则、VFX资产、调色约束
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 指定各场景关键光源、空间色和反差目标
  2. 美术先提供表面反射/色彩风险给摄影
  3. 摄影提交现场目标帧与光位示意
  4. VFX明确需要的参考光和合成范围
  5. 调色记录允许微调与禁止重塑的信息
- **decision_rules / 判断**：若后期改动会抹去角色关键线索则回退; 视觉顾问不等于动画摄影指导
- **outputs / 交付**：visual_bible, scene_color_contract, department_owner_map
- **evidence**：[S003](https://theasc.com/article/flashback-the-shawshank-redemption/)；[S010](https://theasc.com/article/skyfall-mi6-under-siege/)；[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)；[S014](https://theasc.com/article/uncanny-valley-blade-runner-2049/)；[S017](https://theasc.com/article/empire-of-light-deakins/)；[S024](https://www.syfy.com/syfy-wire/awards-contenders-legend-roger-deakins-played-a-huge-role-in-the-how-to-train-your-dragon)
- **examples**：C01, C08, C16, C17, C19, C23, C24
- **limitations**：不能把所有颜色都算现场摄影成果
- **failure_modes**：同一场景跨镜头灯位漂移; 场景美术色与前景服装冲突
- **validation**：同一场景序列光色对照; 跨岗位签收来源与责任
- **ai_adaptation（工程推论）**：AI图像保存场景事实表、固定背景与灯位；视频继承视觉锚；Blender统一材质与世界空间坐标
- **evidence_status**：推论；独创性标识：**不是作者专有定律**。

## M10 · 针对不可控风险配置替代路线 / `conditional_fallback`

- **problem / 问题**：天气/机位/器材不能执行原草案
- **trigger / 调用条件**：存在可排序的优先级与有限资源
- **prerequisites / 前提**：约束、任务完成最低条件、A/B方案
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 列出每镜最可能失效条件
  2. 先保叙事必须看到的信息与演员状态
  3. 预备不改变视觉关系的简化光源/机位
  4. 如失败涉及场地先提交导演和美术取舍
  5. 记录失效原因，避免把暂定结果写成作者定论
- **decision_rules / 判断**：若替代方案改变人物视点则升级导演批准; 无法给出真实镜头参数则停在约束级别
- **outputs / 交付**：risk_register, fallback_plan, approval_requests
- **evidence**：[S004](https://www.latimes.com/archives/la-xpm-1997-03-23-ca-41081-story.html)；[S010](https://theasc.com/article/skyfall-mi6-under-siege/)；[S012](https://theasc.com/post/the-film-book/sicario-interview-with-roger-deakins-asc-bsc/)；[S016](https://theasc.com/article/lives-under-siege-the-goldfinch-and-1917/)；[S018](https://www.rogerdeakins.com/forums/topic/lighting/)
- **examples**：C04, C09, C15, C20
- **limitations**：有限预算≠必然省灯；各项目取舍相反
- **failure_modes**：等光耽误排期; 空间不够却强行复制复杂器材
- **validation**：至少一条可在同等叙事下落地的备选; 有明确触发阈值或现象
- **ai_adaptation（工程推论）**：AI生成失败时改变镜头拆分/运镜需求而非无限堆形容词
- **evidence_status**：推论；独创性标识：**不是作者专有定律**。

## M11 · 只对有叙事理由的段落使用特定光学效果 / `optical_effect_as_exception`

- **problem / 问题**：整个作品被“复古失焦”等效果遮蔽信息
- **trigger / 调用条件**：特定叙事段落要求与角色信息可分离
- **prerequisites / 前提**：段落目的、观众注意区、需保清晰的画面部分
- **inputs / 输入**：场景剧本与叙事任务, 角色走位和场地约束, 导演视觉意图, 现有镜头/光源/资产条件
- **procedure / 操作**：
  1. 先用常规镜头制作基础版本
  2. 写清效果改变了哪类信息/时间感
  3. 限定效果出现的镜头范围
  4. 测试清晰中心、模糊边缘下关键动作可见性
  5. 若引发混淆则撤掉效果
- **decision_rules / 判断**：效果必须局部有理由; 没有原始参数不可声称复原原镜头
- **outputs / 交付**：effect_scope, comparison_frames
- **evidence**：[S009](https://theasc.com/article/shot-craft-lens-test-the-deakinizer/)；[S002](https://studentfilmmakers.com/cinematograter-roger-deakins-asc-bsc/)
- **examples**：C07
- **limitations**：Deakinizer是特定镜头开发，不是Roger默认镜头
- **failure_modes**：在全部电影加涂抹边缘; AI几何变形破坏人物一致性
- **validation**：与无效果版本对比叙事和身份辨认
- **ai_adaptation（工程推论）**：AI以“中心保留清晰、边缘轻微像差”等目标描述并加不变形限制
- **evidence_status**：推论；独创性标识：**不是作者专有定律**。
