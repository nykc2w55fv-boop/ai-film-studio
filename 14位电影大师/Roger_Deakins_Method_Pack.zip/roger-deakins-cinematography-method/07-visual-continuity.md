# 色彩、影调和连续性

## 三层归属不能混写

1. **现场**：美术的色墙与布景反射率、灯具的光源方向、摄影机曝光与镜头选择、演员的位置；《Skyfall》上海LED屏的彩光是典型现场主视觉（S010）。
2. **后期**：最终DI、合成、不同放映媒介。S014具体记录《2049》由Mitch Paulson与Deakins参与全片调色和交付版本；S016的燃烧教堂以CG替代，现场火光需同步。
3. **不确定**：无法从单张剧照识别哪个色彩偏移是灯胶、道具颜色、校色、CG还是观看平台转换。**禁止**据静帧发明LUT、曝光值或灯位。

## 影片间反例

《缺席的人》由科恩兄弟提出黑白方向，Roger采用彩色负片/后续黑白成片（S006）。《老兄，你在哪儿？》是本人承认大量DI改造的例外（S018、S002）。这说明“尽量现场完成”的一般偏好不是“从不使用DI”的强规则。

## 连续性规格（本研究的工作框架，不是Deakins标准）

**Scene Visual Bible**：

```yaml
scene_id: EXAMPLE-01
narrative_priority: '先看到人物发现门闩，再看到门外威胁'
world_space:
  entrance: 'east'
  main_window: 'north'
lighting:
  motive: 'north window diffuse daylight'
  direction: 'north to south'
  continuity_lock: ['direction','color_family','time_of_day']
camera:
  screen_direction: 'subject moves left-to-right'
  coverage_required: ['action','reaction','spatial_establishing']
look:
  contrast_intent: 'soft but legible'
  LUT: null
post:
  vfx_required: false
  grading_changes_allowed: ['minor consistency matching']
```

这是教学示例，空间朝向/方向为原创虚构数据，不是任何Deakins影片的资料。

## 检验

- 相邻镜头切换前后：阴影方向、门窗相对位置、人物服装材质、主要光源强弱是否突变。
- 光源变化必须有剧情原因（车灯转向、火光消退、角色开关灯）或被标记为制作误差。
- AI工作流不能把视频模型的随机颜色漂移解释成“摄影风格”。
- 大型制作提交同场景光参考帧与VFX色彩测试；小型制作使用固定虚拟场景、关键帧对照实现。
