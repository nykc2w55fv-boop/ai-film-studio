# 02. Source Registry

## 来源分级

A级：专业机构、原始档案、原始影像或技术权威。\
B级：直接合作人员回忆、专业访谈和可信二手研究。\
C级：拍卖目录、非官方转录、专业个人网站，只作为线索或辅助证据。

  ------------------------------------------------------------------------------------------------------------------------------------------------------
  ID    来源               日期         等级   支持内容                                                                   局限
  ----- ------------------ ------------ ------ -------------------------------------------------------------------------- ------------------------------
  S01   Art Directors      持续维护     A      职业经历、工作室经历、岗位、75部以上影片、镜头视野能力                     人物简介，不是逐片档案
        Guild, Harold                                                                                                     
        Michelson Hall of                                                                                                 
        Fame                                                                                                              

  S02   BFI, Storyboarding 2013-03-28   A      《群鸟》原始分镜、乌鸦聚集和袭击顺序                                       只覆盖公开画格
        terror:                                                                                                           
        Hitchcock's The                                                                                                   
        Birds turns 50                                                                                                    

  S03   Criterion, Daniel  2017-04-27   B      Camera Angle Projection 教学、原始分镜、合作回忆                           回顾性访谈
        Raim interview                                                                                                    

  S04   Filmmaker          2017-04-28   B      《毕业生》排演现场、模拟空间和分镜过程                                     主要为导演 Raim 回忆
        Magazine, Daniel                                                                                                  
        Raim interview                                                                                                    

  S05   TCM, Harold and    2017-08-21   B      两人岗位边界、主要作品                                                     二手人物文章
        Lillian: A                                                                                                        
        Hollywood Love                                                                                                    
        Story                                                                                                             

  S06   The Credits /      2017-04-27   B      《十诫》分镜师身份、《毕业生》分镜与摄影执行关系                           归属判断需交叉核对
        Motion Picture                                                                                                    
        Association                                                                                                       

  S07   Zeitgeist Films    2016         B      Camera Angle                                                               回顾性陈述
        press kit /                            Projection、镜头/高度/俯仰小型平面图、《群鸟》《艳贼》《毕业生》工作说明   
        director statement                                                                                                

  S08   Steven D. Katz,    1991         B      连续性绘制、制作插画分类、投影方法                                         教材不是哈罗德本人出版的手册
        Film Directing:                                                                                                   
        Shot by Shot                                                                                                      

  S09   VES Handbook,      2010         A/B    平面、立面、摄影机站点、视角、画幅和透视投影步骤                           重印 Katz
        Camera Angle                                                                                                      内容，不是独立历史证据
        Projection                                                                                                        

  S10   American           2024         A      区分几何畸变和透视畸变                                                     通用摄影技术
        Cinematographer,                                                                                                  
        Understanding Lens                                                                                                
        Distortion                                                                                                        

  S11   American           2016         A      视角、放大率、摄影机距离和透视                                             通用摄影技术
        Cinematographer,                                                                                                  
        Practical Optics 1                                                                                                

  S12   Science Museum     馆藏记录     A      《十诫》红海场景的模型、遮罩和光学合成                                     不是哈罗德分镜
        Group, Red Sea                                                                                                    
        production                                                                                                        
        photographs                                                                                                       

  S13   Heritage Auctions, 2010         C      351张原始分镜档案线索                                                      元数据有制片厂/年份冲突
        Ten Commandments                                                                                                  
        storyboard                                                                                                        
        collection                                                                                                        

  S14   Heritage Auctions, 2024         C      100余张海战分镜线索                                                        拍卖目录描述，未逐幅审查
        Ben-Hur sea-battle                                                                                                
        storyboard                                                                                                        
        collection                                                                                                        

  S15   Academy of Motion  2017-04-26   A      两人身份、作品范围、岗位分工                                               活动介绍
        Picture Arts and                                                                                                  
        Sciences event                                                                                                    
        page                                                                                                              

  S16   The Film Stage,    2024-02-01   B      《艳贼》赛马场和狩猎分镜档案、研究者访谈                                   回忆性档案研究
        Tony Lee Moral                                                                                                    
        interview                                                                                                         

  S17   USC Libraries /    档案指南     A      MGM《宾虚》相关制作档案存在                                                部分资料尚未整理且访问受限
        OAC, MGM                                                                                                          
        Production                                                                                                        
        Department files                                                                                                  

  S18   TCM, Behind the    2010-01-21   B      Mike Nichols 对场景戏剧构想的回忆                                          不单独证明镜头归属
        Camera -- The                                                                                                     
        Graduate                                                                                                          

  S19   All About The      2000         C      Harold 与 Robert Boyle 对《群鸟》流程的回忆                                非官方转录，应核对原片
        Birds documentary                                                                                                 
        transcript mirror                                                                                                 

  S20   SHOT BY SHOT,      持续维护     C      《群鸟》分镜与成片对照观察                                                 个人专业网站
        Harold Michelson                                                                                                  
        page                                                                                                              

  S21   Los Angeles Times, 2017-05-11   B      《毕业生》构图、《十诫》视觉构思、未署名工作                               新闻人物报道
        Harold and Lillian                                                                                                
        profile                                                                                                           

  S22   Elsevier / Michael 出版信息     A/B    Katz 教材书目和版本                                                        不能替代书内具体内容
        Wiese book listing                                                                                                
  ------------------------------------------------------------------------------------------------------------------------------------------------------

## 原始链接

-   S01 https://adg.org/awards/hall-of-fame/harold-michelson/
-   S02
    https://www.bfi.org.uk/features/storyboarding-terror-hitchcocks-birds-turns-50
-   S03
    https://www.criterion.com/current/posts/4521-couple-behind-the-curtain-a-conversation-with-daniel-raim
-   S04
    https://filmmakermagazine.com/102303-behind-the-graduates-leg-shot-daniel-raim-on-harold-and-lillian-a-hollywood-love-story/
-   S05
    https://www.tcm.com/articles/1348577/harold-and-lillian-a-hollywood-love-story
-   S06
    https://www.motionpictures.org/2017/04/harold-and-lillian-hollywood-love-story-doc-writer-director-unsung-film-heroes/
-   S07
    https://zeitgeistfilms.com/userFiles/uploads/films/269/HAROLD_AND_LILLIAN_Press_Kit_newest2.pdf
-   S08
    https://shop.elsevier.com/books/film-directing-shot-by-shot/katz/978-0-08-094817-1
-   S09
    https://s3-eu-west-1.amazonaws.com/s3-euw1-ap-pe-ws4-cws-documents.ri-prod/9780240825182/Chapter2.pdf
-   S10 https://theasc.com/article/understanding-lens-distortion/
-   S11
    https://theasc.com/post/the-film-book/practical-optics-testing-different-sensor-sizes/
-   S12
    https://collection.sciencemuseumgroup.org.uk/objects/co8615842/extras-approaching-the-other-side-toward-rock-of-moses
-   S13
    https://entertainment.ha.com/itm/movie-tv-memorabilia/the-ten-commandments-collection-of-storyboard-drawings/a/997077-863.s
-   S14
    https://entertainment.ha.com/c/catalog-print.zx?ic5=CatalogHome-AucType-PrintableCatalog-071515&saleNo=7356
-   S15
    https://www.oscars.org/events/harold-and-lillian-hollywood-love-story-2017
-   S16
    https://dev.thefilmstage.com/exclusive-alfred-hitchcocks-never-before-published-storyboards-peel-the-torn-curtain-back-on-his-legendary-career/
-   S17 https://oac.cdlib.org/findaid/ark:/13030/c8j67qj2
-   S18
    https://www.tcm.com/articles/288407/behind-the-camera-the-graduate
-   S19
    https://the.hitchcock.zone/wiki/All_About_The_Birds\_%282000%29\_-\_transcript
-   S20 https://www.shotbyshotbook.com/harold-michelson
-   S21
    https://www.latimes.com/entertainment/movies/la-et-mn-harold-and-lillian-20170501-story.html
-   S22 https://www.shroffpublishers.com/books/9789368080190/

## 审查规则

1.  关键历史事实至少有一条 A 级来源或两条相互独立的 B 级来源支持。
2.  拍卖目录只作为档案线索，不能代替原件检查。
3.  纪录片转录应标明转录性质，不能伪装成哈罗德正式出版的文章。
4.  成片与分镜相似，不足以证明最终摄影决策的全部归属。
5.  技术公式应引用标准摄影/投影知识，不应归为哈罗德独创。

## 补充来源 S23

**American Cinematographer --- The Photography of Ben-Hur**\
https://theasc.com/article/flashback-ben-hur-1959/

该资料记录《宾虚》战车竞赛由 Andrew Marton / Piero Portalupi
等摄影团队执行，并说明他们使用制片厂提供的分镜指导。文章没有把这些分镜归于
Harold
Michelson，因此只用于说明影片摄影规划背景，不作为哈罗德个人署名证据。
