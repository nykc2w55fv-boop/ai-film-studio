# 09. Method Cards

## 方法总览

  ID       方法                      证据状态
  -------- ------------------------- ----------------
  HM-M01   剧本/排演到视觉节拍       案例 + 推论
  HM-M02   Camera Angle Projection   有文献记录
  HM-M03   连续性画格与动作分解      有原始分镜支持
  HM-M04   渐进式视觉信息揭示        案例归纳
  HM-M05   空间化人物关系            案例归纳
  HM-M06   复杂事件视觉分解          案例归纳
  HM-M07   导演---分镜---摄影协作    访谈/回忆支持
  HM-M08   分镜交付类型识别          通用领域知识
  HM-M09   镜头可拍摄性与空间预检    工程扩展

## HM-M01 --- 剧本/排演到视觉节拍

**English:** Script and Rehearsal to Visual Beats

-   **problem：** 文字剧本或排演动作尚未形成可执行镜头序列。
-   **trigger：** 场景有明确行动、人物关系变化、信息揭示或需要视觉化。
-   **prerequisites：** 至少有场景目标、人物和空间基本信息。
-   **inputs：** 剧本、导演意图、排演记录、场景参考。
-   **procedure：**
    识别人物目标和阻力；标记可见动作和信息变化；拆分动作状态；识别关键视觉瞬间；确定镜头边界；为镜头写明目的。
-   **decision_rules：**
    不按句号或对白轮次机械切镜；动作、信息、视角或空间关系变化时才考虑新镜头。
-   **outputs：** visual_beats、shot_list、director_questions。
-   **evidence：** S04、S07。
-   **examples：** The Graduate 排演现场；The Birds
    的剧本与制作设计讨论。
-   **limitations：** 回忆资料不能证明所有项目都采用同一流程。
-   **failure_modes：** 每句对白一张图；只画漂亮关键帧；忽略动作状态。
-   **validation：** 删除一个镜头后检查是否丢失必要信息或动作衔接。
-   **ai_adaptation：**
    将剧本解析为事件和状态，保留导演意图与推论的区分。
-   **evidence_status：** CASE_AND_INFERENCE。

## HM-M02 --- 镜头角度投影

**English:** Camera Angle Projection

-   **problem：** 分镜无法准确反映指定机位和镜头视角下的实际画面。
-   **trigger：**
    狭小空间、复杂前后景、画幅边界关键、需要预判搭景或特效摄影。
-   **prerequisites：**
    平面图/现场测量、摄影机位置、焦距与成像面尺寸、画幅比例。
-   **inputs：**
    scene_plan、elevation、camera_station、lens、sensor_gate、aspect_ratio。
-   **procedure：**
    计算水平/垂直视角；放置摄影机站点；绘制视野边界；建立画面平面和地平线；投射空间关键点；用立面确定高度；建立消失点；检查遮挡和边界。
-   **decision_rules：**
    缺少传感器尺寸或机位时不得声称精确投影；高低角度应使用三点透视或三维验证。
-   **outputs：** camera_projection、frame_bounds、camera_plan。
-   **evidence：** S03、S04、S07、S08、S09。
-   **examples：** Harold 在 AFI 教授 Camera Angle Projection；The
    Graduate 房屋平面和镜头构思。
-   **limitations：** 没有公开每部影片的完整镜头参数。
-   **failure_modes：**
    把焦距误当成透视唯一决定因素；忽略画幅；补造未知机位。
-   **validation：** 与 Blender 针孔相机投影对照，检查关键点误差。
-   **ai_adaptation：** 由几何数据控制相机，图像模型只负责视觉表现。
-   **evidence_status：**
    DOCUMENTED_HISTORICAL_METHOD_WITH_ENGINEERING_EXTENSION。

## HM-M03 --- 连续性画格与动作分解

**English:** Continuity Panels and Action Decomposition

-   **problem：** 复杂动作无法由单张图解释，镜头间容易遗漏动作或跳变。
-   **trigger：** 人物进出画面、追逐、群体运动、危险发生、道具转移。
-   **prerequisites：** 动作起点/终点和主要空间锚点已知。
-   **inputs：**
    action_sequence、actor_positions、camera_positions、spatial_anchors。
-   **procedure：**
    标记动作起始状态；找出动作变化节点；为关键节点选择镜头；绘制构图；记录动作方向；检查前后镜头状态。
-   **decision_rules：** 只保留对动作理解、空间理解或剪辑点有用的画格。
-   **outputs：** continuity_board、action_beats、screen_direction_map。
-   **evidence：** S01、S02、S08、S09、S19。
-   **examples：** The Birds 儿童离校、鸟群袭击和人物逃离。
-   **limitations：** 公开分镜不是整部影片完整档案。
-   **failure_modes：** 缺少动作过渡；动作方向反转；人物位置无原因跳变。
-   **validation：** 不看文字说明，仅按画格顺序复述动作。
-   **ai_adaptation：** 每个 panel 绑定 actor_state 和 action_state。
-   **evidence_status：** DOCUMENTED_WITH_ENGINEERING_EXTENSION。

## HM-M04 --- 渐进式视觉信息揭示

**English:** Progressive Visual Revelation

-   **problem：** 观众需要逐步发现威胁、线索或环境变化。
-   **trigger：** 悬疑、惊悚、伏笔、隐藏人物、逐渐形成的危险。
-   **prerequisites：** 明确观众知道什么、人物知道什么。
-   **inputs：**
    threat_states、audience_knowledge、character_knowledge、visual_anchors。
-   **procedure：**
    建立正常状态画面；引入初始线索；重复展示同一空间；逐步提高线索可见度；调整人物与观众的信息差；将揭示转化为行动。
-   **decision_rules：**
    每次重复展示必须带来新信息；没有变化的重复镜头应考虑删除。
-   **outputs：** reveal_sequence、information_state_table。
-   **evidence：** S02、S16、S20。
-   **examples：** The Birds 乌鸦聚集场景。
-   **limitations：** 不能把单一影片的节奏当成所有悬疑片公式。
-   **failure_modes：**
    过早暴露危险；观众看不见线索；重复镜头无信息变化。
-   **validation：** 让未看过剧本的观众记录何时发现危险。
-   **ai_adaptation：** 以离散状态控制每个镜头的可见信息。
-   **evidence_status：** CASE_DERIVED_INFERENCE。

## HM-M05 --- 空间化人物关系

**English:** Spatialized Character Relationships

-   **problem：** 人物心理、权力和关系难以通过普通正反打表达。
-   **trigger：** 诱惑、压迫、支配、疏离、亲密、对峙。
-   **prerequisites：** 人物关系和场景空间已明确。
-   **inputs：**
    character_goals、blocking、foreground_objects、background_subjects。
-   **procedure：**
    明确戏剧关系；确定人物空间距离；识别可承担关系信息的前景物体；设计前景/主体/背景；判断同框是否优于切换；检查构图是否服务戏剧任务。
-   **decision_rules：**
    前景遮挡必须有叙事功能；不得把构图方式固定解释为某种情绪。
-   **outputs：** relational_composition、blocking_map、shot_reference。
-   **evidence：** S03、S04、S06、S18、S21。
-   **examples：** The Graduate 腿部前景构图。
-   **limitations：** 构图不能脱离表演、导演意图和摄影执行。
-   **failure_modes：**
    为模仿经典画面牺牲人物行动；遮挡无意义；背景人物不可读。
-   **validation：** 隐去对白，检查画面是否传递预期关系。
-   **ai_adaptation：** 以遮挡比例、主体位置和深度层次作为结构参数。
-   **evidence_status：** CASE_DERIVED_INFERENCE。

## HM-M06 --- 复杂事件视觉分解

**English:** Complex Event Visualization

-   **problem：** 大型事件包含多人物、环境变化、群体动作和特效。
-   **trigger：** 群众场面、灾难、战斗、追逐、环境破坏、复杂特效。
-   **prerequisites：** 事件阶段、空间边界和主要行动者明确。
-   **inputs：**
    event_states、crowd_paths、environment_changes、effects_requirements。
-   **procedure：**
    拆分事件状态；分离人物/群体/环境/特效动作；确定每阶段观众必须看到的信息；规划镜头功能；标注摄影机和行动方向；区分实拍/模型/绘景/合成。
-   **decision_rules：**
    不为每个群体成员单独画镜头；优先表达整体方向和关键人物。
-   **outputs：** event_board、crowd_map、effects_handoff。
-   **evidence：** S01、S06、S12、S13、S14。
-   **examples：** The Ten Commandments 红海场景；Ben-Hur
    海战分镜档案线索。
-   **limitations：** 分镜不能代替视效执行方案。
-   **failure_modes：**
    群体方向不清；空间尺度不一致；把特效预演误当实际拍摄计划。
-   **validation：** 用代理模型检查群体路径、遮挡和镜头覆盖。
-   **ai_adaptation：** 使用状态机、路径数据和场景代理模型。
-   **evidence_status：** CASE_DERIVED_ENGINEERING_EXTENSION。

## HM-M07 --- 导演---分镜---摄影协作

**English:** Director--Storyboard--Cinematography Collaboration

-   **problem：** 导演抽象意图无法转化为摄影部门可执行方案。
-   **trigger：** 特殊构图、复杂动作、摄影机限制、多部门协作。
-   **prerequisites：** 导演目标和场景条件明确。
-   **inputs：**
    director_intent、script、rehearsal、production_design、camera_constraints。
-   **procedure：**
    记录戏剧目标；与制作设计确认空间；观察排演或建立代理场景；提出镜头方案；向导演确认重点；与摄影部门核对可行性；记录修改理由。
-   **decision_rules：** 分镜是工作文件，不是限制导演的最终命令。
-   **outputs：** approved_storyboard、camera_handoff、revision_log。
-   **evidence：** S03、S04、S06、S07、S19。
-   **examples：** The Birds 与 Robert Boyle；The Graduate 与 Mike
    Nichols、Robert Surtees。
-   **limitations：** 不同影片协作流程不同。
-   **failure_modes：** 把导演意图误当摄影参数；未确认即交给生成模块。
-   **validation：** 导演、摄影和分镜岗位能否用同一文件理解镜头。
-   **ai_adaptation：** 未确认的视觉决策设置 `review_required=true`。
-   **evidence_status：** DOCUMENTED_WITH_ENGINEERING_EXTENSION。

## HM-M08 --- 分镜交付类型识别

**English:** Visualization Deliverable Classification

-   **problem：** 概念插画、分镜、连续性图和技术投影被混用。
-   **trigger：** 任务输入或交付物类型不清。
-   **prerequisites：** 明确接收者和交付目的。
-   **inputs：** request、production_stage、recipient_role。
-   **procedure：**
    判断是否表达氛围；是否表达连续镜头；是否表达场景尺寸；是否表达摄影机视野；选择交付类型；标记文件不能证明的内容。
-   **decision_rules：** 不能因为图像看起来像电影就归类为可拍摄分镜。
-   **outputs：** deliverable_type、deliverable_spec。
-   **evidence：** S08、S09。
-   **examples：** 概念设计图与连续性画格的区别。
-   **limitations：** 不同工作室文件名称可能不同。
-   **failure_modes：** 概念图被误交为镜头表；平面图被误当作摄影机视图。
-   **validation：** 交付物是否满足接收岗位的实际用途。
-   **ai_adaptation：** 输出前强制选择 `deliverable_type`。
-   **evidence_status：** STANDARD_FIELD_KNOWLEDGE。

## HM-M09 --- 镜头可拍摄性与空间预检

**English:** Shot Feasibility and Spatial Preflight

-   **problem：** 分镜画面漂亮，但摄影机、演员、场景或特效无法实现。
-   **trigger：** 重要镜头、复杂场景、窄空间、多人调度、特效镜头。
-   **prerequisites：** 粗略空间模型和摄影机参数至少部分可用。
-   **inputs：**
    shot_list、scene_geometry、camera_specs、blocking、production_limits。
-   **procedure：**
    检查摄影机物理位置；检查镜头视野；检查遮挡；检查人物路径；检查设备和演员空间；检查特效边界；标记未验证参数；请求岗位确认。
-   **decision_rules：** 缺少空间数据时只能标记未验证，不能声称可拍摄。
-   **outputs：** feasibility_report、previs_scene、review_items。
-   **evidence：** S08、S09、S10。
-   **examples：** 教材中的摄影机视野与搭景空间冲突示例。
-   **limitations：** 三维预演不能完全模拟演员表演、灯光和现场条件。
-   **failure_modes：**
    摄影机穿墙；画幅边界错误；演员路径不可执行；关键动作被遮挡。
-   **validation：** Blender 代理场景复核；摄影指导人工确认。
-   **ai_adaptation：** 关键几何字段未解决时禁止自动通过。
-   **evidence_status：** ENGINEERING_EXTENSION。
