# 02 — 来源登记表

证据等级：A = 本人文章/演讲/直接访谈；B = 直接参与者或官方制作报道；C = 官方岗位署名/电影资料库；D = 第三方署名聚合，仅辅助核查。

| source_id | 标题 | 作者/发布方 | 日期 | 等级 | 链接 |
|---|---|---|---|---|---|
| S01 | Randy Thom 人物资料 | Skywalker Sound | 持续更新 | B/C | https://www.skysound.com/people/randy-thom/ |
| S02 | Randy Thom Looks Back on 40 Years with Skywalker Sound | Lucasfilm / Lucas O. Seastrom | 2019-12-09 | A/B | https://www.lucasfilm.com/news/randy-thom-looks-back-on-40-years-with-skywalker-sound/ |
| S03 | Designing A Movie For Sound | Randy Thom | 原文 1990 年代；博客 2017-05-05 | A | https://randythom.blog/2017/05/05/designing-a-movie-for-sound/ |
| S04 | Designing a Film for Sound（Cinesonic 演讲转录） | Randy Thom；Philip Brophy 转录编辑 | 演讲 1999；出版 2000 | A | https://www.philipbrophy.com/projects/cinesonic/randythom.html |
| S05 | RANDY THOM — SOUND DESIGNER | Motion Picture Editors Guild | 2021-06 | A/B | https://www.editorsguild.com/About/What-Do-Our-Members-Do/Past-Featured-Members/ArticleID/388/RANDY-THOM-SOUND-DESIGNER |
| S06 | Randy Thom: 2014 MPSE Career Achievement Award Honoree | CineMontage / Mel Lambert | 2014-03-01 | A/B | https://cinemontage.org/randy-thom-2014-mpse-career-achievement-award-honoree/ |
| S07 | Randy Thom Filmography | AFI Catalog | 持续更新 | C | https://catalog.afi.com/Person/201494-Randy-Thom |
| S08 | Empire at 40 — Sound Designer Ben Burtt Interview | StarWars.com | 2020 | B | https://www.starwars.com/news/empire-at-40-ben-burtt-interview |
| S09 | Jedi at 40 — Ben Burtt and Randy Thom | StarWars.com | 2023-05-25 | A/B | https://www.starwars.com/news/jedi-at-40-ben-burtt-randy-thom |
| S10 | Harnessing the Elements on Cast Away | Mix / Michael Axinn | 2001-01-01 | A/B | https://www.mixonline.com/recording/harnessing-elements-cast-away-374858 |
| S11 | Randy Thom | Mix / Maureen Droney | 2005 | A/B | https://www.mixonline.com/sfp/randy-thom-369110 |
| S12 | Skywalker Sound’s Randy Thom Looks Back on The Incredibles | Skywalker Sound / Lucas O. Seastrom | 2024-12-27 | A/B | https://www.skysound.com/news/skywalker-sounds-randy-thom-looks-back-on-brad-birds-the-incredibles/ |
| S13 | Ratatouille — Interview with Randy Thom | Designing Sound | 2007-06-26 | A/B | https://designingsound.org/2007/06/26/ratatouille-exclusive-interview-with-sound-designer-randy-thom/ |
| S14 | How to Train Your Dragon — Interview with Randy Thom, Jonathan Null and Al Nelson | Designing Sound | 2010-04-26 | A/B | https://designingsound.org/2010/04/26/how-to-train-your-dragon-exclusive-interview-with-randy-thom-jonathan-null-and-al-nelson/ |
| S15 | Collaborating with the Music Team | Designing Sound / Shaun Farley | 2013-03-05 | A | https://designingsound.org/2013/03/05/collaborating-with-the-music-team-an-interview-with-randy-thom/ |
| S16 | How To Train Your Dragon 2 Is More Growly And Snarly (And Wise) Than Ever | NPR / WBUR | 2014 | A/B | https://www.wbur.org/npr/321323569/how-to-train-your-dragon-2-is-more-growly-and-snarly-and-wise-than-ever |
| S17 | How Randy Thom & Al Nelson crafted The Hidden World's sound | A Sound Effect / Jennifer Walden | 2019-02-28 | A/B | https://www.asoundeffect.com/how-to-train-your-dragon-3-sound/ |
| S18 | Crafting How To Train Your Dragon | Skywalker Sound | 2019-02-28 | B | https://www.skysound.com/latest/crafting-how-to-train-your-dragon/ |
| S19 | Randy Thom Brings His Love of Sonic Storytelling to The Wild Robot | Skywalker Sound / Clayton Sandell | 2025-01-02 | A/B | https://www.skysound.com/news/skywalker-sounds-randy-thom-brings-his-love-of-sonic-storytelling-to-the-wild-robot/ |
| S20 | The Sound of The Wild Robot | Dolby Creator Talks | 2024-09-30 | A/B | https://www.dolby.com/en-in/creator-lab/dolby-creator-talks/episode-210/ |
| S21 | Behind the Action-Packed Sound of the Live-Action How to Train Your Dragon | A Sound Effect / Jennifer Walden | 2025-08-14 | A/B | https://www.asoundeffect.com/how-to-train-your-dragon-randy-thom/ |
| S22 | More Notes on Creature Sound Design | Randy Thom / Patreon | 页面显示 August 17；年份未明确 | A | https://www.patreon.com/RandyThom/posts/more-notes-on-166943300 |
| S23 | Notes on Sound Design in Contemporary Animated Films | Randy Thom / Oxford Handbook | 2013-08-01 | A | https://doi.org/10.1093/oxfordhb/9780199733866.013.018 |
| S24 | Official Skywalker Sound Project Credits | Skywalker Sound | 持续更新 | C | https://www.skysound.com/projects/ |
| S25 | Sonic Storytelling: Go Beyond the Gates of Skywalker Ranch | Skywalker Sound | 2025 | B | https://www.skysound.com/news/sonic-storytelling-go-beyond-the-gates-of-skywalker-ranch-to-the-heart-of-skywalker-sound/ |
| S26 | The Croods — Screen Credits | CrewCredits | 持续更新 | D/C | https://crewcredits.com/projects/42 |
| S27 | How to Train Your Dragon 2 — Screen Credits | CrewCredits | 持续更新 | D/C | https://crewcredits.com/projects/44 |

## 来源使用说明

- S03 是早期文章的博客再发布，不能把 2017 年误写为方法首次提出年份。
- S04 是演讲转录编辑版本，不是未经编辑的现场逐字稿。
- S08 明确区分 Thom 的原始录音和 Ben Burtt 的选择、剪辑。
- S09 用于核实《绝地归来》的分工。
- S21 本轮网页抓取不稳定，正式导入前应人工复核原文。
- S22 页面显示 August 17，但本轮摘录未明确年份。
- S26、S27 是第三方署名数据库，不作为方法结论的单独证据。

| S29 | Sound Storyboarding: One Part of Designing a Movie for Sound | Randy Thom | 2026-06-11 | A | https://randythom.blog/2026/06/11/sound-storyboarding-one-part-of-designing-a-movie-for-sound/ |

