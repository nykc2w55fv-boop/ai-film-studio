# 01 — 身份、职业经历与作品署名

## 1. 身份核实

Randy Thom 是美国电影声音设计师，长期任职于 Skywalker Sound。Skywalker Sound 官方人物资料列出他的职位范围包括 Director of Sound Design、Supervising Sound Editor、Sound Designer、Re-recording Mixer。[S01]

他最初在公共广播电台工作，参与录音、广播剧、纪录节目和声音编辑。随后通过 Walter Murch 进入电影声音行业。[S04][S05]

## 2. 职业路径

| 阶段 | 可核实经历 | 研究意义 |
|---|---|---|
| 公共广播 | 录音、声音编辑、广播剧与纪录节目 | 形成以声音本身组织叙事的经验 |
| 《现代启示录》（1979） | 音效录音、混音助理等职责；Walter Murch 负责主要声音设计 | 现场采集与混音观察是早期训练，不应误记为全片声音设计 |
| 《帝国反击战》（1980） | 音效录音；为 AT-AT 步行机采集金属剪切/冲压机器素材 | 真实世界素材可成为虚构声音的基础，后续剪辑和设计由 Ben Burtt 组织 |
| 1980 年代 | 现场录音、声音设计、重新录音混音等多种岗位 | 形成跨岗位视角，但各岗位仍需区分 |
| 1990 年代 | 《阿甘正传》《超时空接触》等项目中承担声音设计和重新录音混音 | 声音系统性参与人物视角与叙事结构 |
| 2000 年以后 | 《荒岛余生》《超人总动员》《料理鼠王》《驯龙高手》等 | 环境声、原创音效、动画前期协作和角色声音设计案例更丰富 |
| 近年 | 《荒野机器人》、真人版《驯龙高手》 | 机器人/生物声音身份、演员表演与合成声音的平衡 |

## 3. 重要合作关系

- **Walter Murch**：Thom 的早期导师。Murch 邀请他观察《美国风情画》的立体声重混，之后让他参与《现代启示录》。
- **Ben Burtt**：在《帝国反击战》等项目合作。Burtt 负责声音设计方向，Thom 为帝国步行机采集金属机械素材。
- **George Lucas**：通过 Sprocket Systems/Skywalker Sound 的协作环境，Thom 得以较早参与项目和跨岗位讨论。
- **Francis Ford Coppola**：通过《现代启示录》合作。
- **Robert Zemeckis**：长期合作，代表项目包括《阿甘正传》《超时空接触》《荒岛余生》。Thom 提到 Zemeckis 支持音乐与音效前期协调。
- **Brad Bird**：合作《钢铁巨人》《超人总动员》《料理鼠王》等项目。Bird 会在声音草图阶段提供具体反馈。
- **Chris Sanders / Dean DeBlois**：合作《驯龙高手》系列和《荒野机器人》等项目，声音设计与动画/故事开发的前期协作较明确。

## 4. 岗位边界

| 岗位 | 一般职责 | 不应自动推断的内容 |
|---|---|---|
| Sound Designer | 发展影片声音美学和设计策略，设计或监督制作具体声音 | 不代表亲自录制、剪辑、混音所有音轨 |
| Supervising Sound Editor | 组织、监督声音剪辑工作和团队协作 | 不代表本人完成全部声音剪辑 |
| Sound Editor | 剪辑指定声音元素，如音效、对白、环境等 | 不等于声音设计总负责人 |
| Sound Effects Recordist | 采集原始音效素材 | 不等于最终声音设计师 |
| Production Sound Mixer | 现场录制对白及现场声音，协调麦克风和录音 | 不等于后期音效设计师 |
| Re-recording Mixer | 混音阶段平衡对白、音效、音乐和空间关系 | 不等于每条素材的录制者或设计者 |
| Dialogue Editor | 整理对白、ADR、对白连续性 | 不等于演员表演或声音设计总负责人 |
| Foley Artist | 表演并录制脚步、动作、物体互动等拟音 | 不等于音效编辑或混音师 |
| Composer | 创作音乐 | 不等于声音设计师 |
| Music Editor | 编辑、组织和同步音乐 | 不等于作曲家 |

以上是标准岗位边界说明，不是 Thom 对所有工种的正式定义。一个人可以兼任多个岗位，但不能因此抹掉其他团队成员的贡献。

## 5. 代表影片岗位核查

| 影片 | 可核实的 Thom 岗位/贡献 | 署名边界 |
|---|---|---|
| 《现代启示录》（1979） | 音效录音、后期录音及混音助理；约半数时间在外景采集直升机、枪声、苍蝇等素材 | Walter Murch 是主要声音设计/声音蒙太奇负责人。[S04][S06][S07] |
| 《帝国反击战》（1980） | Sound Effects Recordist；采集 AT-AT 步行机相关金属剪切/冲压机器声 | Ben Burtt 挑选录音并编辑成步行节奏。[S06][S08] |
| 《绝境求生》（Never Cry Wolf，1983） | Production Sound Recording / Sound Mixer | 主要为现场录音职责；现有资料不足以归纳为其声音设计方法。[S06][S07] |
| 《太空先锋》（The Right Stuff，1983） | AFI 记录 Re-recording Mixer；CineMontage 访谈中 Thom 描述自己担任 sound designer / sound effects mixer，并提到采集炸弹爆炸声 | 岗位称谓在资料间有差异，保留原始记录，不强行统一。[S06][S07] |
| 《绝地归来》（1983） | Re-recording Mixer；参与部分美国拍摄素材的现场录音 | Ben Burtt 是 Sound Designer。[S09][S24] |
| 《阿甘正传》（1994） | Sound Designer、Re-recording Mixer | Thom 的演讲有越战段落和长椅回忆转场案例。[S04][S24] |
| 《超时空接触》（1997） | Sound Designer、Re-recording Mixer | Thom 说明前期与 Zemeckis 讨论声音如何影响视觉设计。[S02][S24] |
| 《荒岛余生》（2000） | Sound Designer、Re-recording Mixer | Dennis Leonard 为 Supervising Sound Editor；Tom Johnson 也参与混音。[S10][S24] |
| 《超人总动员》（2004） | Supervising Sound Editor、Sound Designer、Re-recording Mixer | Michael Silvers 也担任 Supervising Sound Editor；Gary Rizzo 参与混音。[S12][S24] |
| 《世界之战》（2005） | Sound Designer | Richard Hymns 为 Supervising Sound Editor。[S24] |
| 《料理鼠王》（2007） | Sound Designer、Re-recording Mixer | Michael Silvers 为 Supervising Sound Editor；Michael Semanick 也参与混音。[S13][S24] |
| 《鬼妈妈》（2009） | Sound Designer、Re-recording Mixer | Tom Johnson 也参与混音。[S24] |
| 《驯龙高手》（2010） | Supervising Sound Editor、Sound Designer、Re-recording Mixer | Gary Rizzo 也参与混音；Jonathan Null、Al Nelson 等共同参与。[S14][S24] |
| 《疯狂原始人》（2013） | 第三方署名数据库列出 Sound Designer、Re-recording Mixer；演员表列出其为 Sandy 配音 | 只作为辅助署名信息，不作为方法案例主要证据。[S26] |
| 《驯龙高手2》（2014） | Supervising Sound Designer、Supervising Sound Editor、Re-recording Mixer | Al Nelson 为 Sound Designer，另有 Shawn Murphy、Brandon Proctor 参与混音。[S16][S27] |
| 《驯龙高手3：隐秘的世界》（2019） | Sound Designer、Supervising Sound Editor | Brian Chumney 也担任 Supervising Sound Editor；Gary A. Rizzo 与 Scott R. Lewis 参与混音。[S17][S18][S24] |
| 《荒野机器人》（2024） | Skywalker 官方项目页列为 Sound Designer | Brian Chumney、Leff Lefferts 为 Supervising Sound Editor；Leff Lefferts 与 Gary Rizzo 参与混音。[S19][S24] |
| 真人版《驯龙高手》（2025） | Thom 访谈说明其负责龙的声音设计 | 采访明确混音由 Paul Massey 与 Leff Lefferts 负责。[S21] |

## 6. 必须排除的归属错误

- 《现代启示录》不能整体归于 Thom；他的早期岗位是录音和混音助理，Walter Murch 负责主要声音设计。
- 《绝地归来》的声音设计师是 Ben Burtt；Thom 的官方项目署名是 Re-recording Mixer。
- 《WALL·E》由 Ben Burtt 监督声音工作。Thom 在访谈中称赞该片，但不能把它列为 Thom 的个人创作案例。[S12]
- 《驯龙高手》系列有 Al Nelson、Jonathan Null、Gary Rizzo 等关键合作者。
- 《荒野机器人》官方项目页与新闻报道对 Thom 的职位描述略有不同，最终岗位清单以官方项目页为准。
