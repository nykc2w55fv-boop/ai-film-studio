# 11 — AI 影视声音设计适配

## 1. 设计目标

把有证据支持的声音叙事方法转化为工具无关的 AI 工作流。ChatGPT、Codex、FFmpeg、Blender、数字音频工作站和 AI 音效生成工具只是可能的实现组件，不假设用户已经安装任何工具。

## 2. 剧本到声音设计

**输入：**
- 剧本/分场。
- 人物设定。
- 场景地点与时间。
- 人物心理变化。
- 导演的情绪目标。
- 摄影/分镜方案。
- 目标片长。
- 已有声音素材与授权状态。

**输出：**
- 逐场声音叙事任务。
- 人物听觉视角。
- 环境声设计。
- 关键音效。
- 声音主题与重复素材。
- 声音转场。
- 静默/相对静默设计。
- 声音对画面、表演和场景的反向建议。
- 需要人工确认的决策。

## 3. AI 工作流

```text
剧本/故事输入
    ↓
场景与人物解析
    ↓
声音叙事机会识别
    ↓
人物听觉视角分析
    ↓
环境与空间分析
    ↓
声音分镜/早期原型任务
    ↓
导演与跨岗位审查
    ↓
素材检索/原创录音/AI 音效生成
    ↓
声音剪辑与临时混音
    ↓
音频时间线输出
    ↓
技术检查 + 人工叙事审听
    ↓
修改与交付
```

## 4. 声音生成任务模板

```yaml
task_id: SFX_TASK_001
scene_id: SCENE_001
shot_id: SHOT_003
narrative_function: "让人物意识到远处有一个大型机械声源"
sonic_pov:
  owner: "主角"
  state: "警觉"
source:
  subject: "大型金属机械"
  action: "间歇性运转"
  material: "金属冲压、摩擦"
acoustic_design:
  distance: "远处"
  direction: "画面右后方"
  dynamics: "低强度、周期性出现"
  temporal_shape: "先模糊，随后逐渐清晰"
emotion: "不安"
duration_seconds: 8
start_state: "低强度远声"
end_state: "保持远处运转"
avoid:
  - "科幻激光音色"
  - "无来源的爆炸声"
  - "持续覆盖对白"
asset_requirements:
  editable: true
  isolated_source_preferred: true
  license_status_required: true
review_required: true
```

这是研究者为 AI 工作流设计的结构，不是 Thom 本人使用的提示词。自然语言生成模型不一定能严格控制距离、动态、声像和事件时间。

## 5. 声音资产库

```json
{
  "sound_id": "SOUND_0001",
  "filename": "wind_coast_01.wav",
  "source_type": "field_recording",
  "original_source": "海岸岩石附近的风声",
  "recording_location": "待填写",
  "recording_date": "待填写",
  "duration_seconds": 12.5,
  "sample_rate": 48000,
  "channel_layout": "stereo",
  "category": ["ambience", "wind", "coast"],
  "acoustic_description": "间歇性低频风噪与高频气流",
  "intended_use": ["孤独", "海岛环境"],
  "license_status": "unknown",
  "copyright_notes": "授权未确认，不得商用",
  "processing_history": [],
  "checksum": null
}
```

`license_status` 建议枚举：
- `original_owned`
- `licensed`
- `public_domain_verified`
- `ai_generated_terms_reviewed`
- `unknown`
- `restricted`

来源不明时必须设为 `unknown`。

## 6. 音频时间线结构

### 时间基准

- 视频帧率：明确写入 `frame_rate_num` 和 `frame_rate_den`。
- 时间线位置：统一使用秒，避免混用帧数与秒。
- 视频与音频同步：通过明确的起始时间和帧率转换。
- 采样率：明确写入，如 48000 Hz；不得把示例值误认为项目强制值。
- 声道布局：stereo、5.1、7.1 等必须与最终交付目标一致。
- 文件路径：使用项目相对路径，避免机器绝对路径。
- 版本控制：每次变更生成新版本，不覆盖原始素材。

### 示例数据结构

```json
{
  "schema_version": "1.0",
  "project_id": "PROJECT_001",
  "scene_id": "SCENE_001",
  "frame_rate_num": 24,
  "frame_rate_den": 1,
  "sample_rate": 48000,
  "channel_layout": "stereo",
  "time_unit": "seconds",
  "clips": [
    {
      "audio_clip_id": "CLIP_001",
      "sound_id": "SOUND_0001",
      "source_file": "assets/ambience/wind_coast_01.wav",
      "source_in": 0.0,
      "source_out": 12.0,
      "timeline_in": 0.0,
      "timeline_out": 12.0,
      "track": "AMB_01",
      "channel_layout": "stereo",
      "gain": -12.0,
      "gain_unit": "dB",
      "pan": 0.0,
      "spatial_position": {
        "azimuth_deg": 0,
        "elevation_deg": 0,
        "distance_class": "far"
      },
      "perspective": "character_subjective",
      "fade_in": 1.0,
      "fade_out": 1.5,
      "processing": [],
      "scene_id": "SCENE_001",
      "shot_id": "SHOT_001",
      "narrative_function": "建立孤独的海岛环境",
      "method_id": "RTM-M04",
      "confidence": 0.78,
      "review_required": true
    }
  ]
}
```

说明：
- `gain` 示例单位为 dB，仅为数据结构示例，不是 Thom 的固定混音设置。
- `confidence` 是 AI 对该设计建议的主观置信标记，不是统计学概率。
- `spatial_position` 可根据立体声、多声道或空间音频系统扩展。
- 实际项目必须验证时间线文件与目标 DAW/编辑软件之间的格式兼容性。

## 7. AI 声音检查

**机器可检测：**
- 文件是否缺失、能否解码。
- 是否出现数字削波。
- 是否存在异常静音或截断。
- 采样率、声道数是否符合项目要求。
- 时间线是否越界。
- 是否有素材路径失效。
- 音频与视频同步是否偏移。
- 是否有未授权素材标记。

**需要人工判断：**
- 人物听觉视角是否正确。
- 声音是否帮助观众理解故事。
- 环境是否具有身份。
- 角色声音是否连续。
- 音乐与音效是否互相遮蔽。
- 静默是否有效。
- 声音是否与画面和表演形成一致的叙事关系。

## 8. AI 自动化边界

AI 可以解析剧本、生成声音分镜草案、搜索素材库、推荐候选、生成音效提示词、输出音频时间线结构、运行技术检查。

AI 不应未经人工确认：
- 自动将未知授权素材用于商业影片。
- 将主观 POV 设计当成客观声学事实。
- 把生成音效直接认定为最终混音。
- 把所有声音岗位的工作归给单一声音设计师。
- 在缺少实际试听时声称声音设计达到电影级质量。
