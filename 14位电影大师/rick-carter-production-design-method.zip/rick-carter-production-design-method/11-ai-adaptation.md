# 11. Rick Carter 制作设计方法论的 AI 工程化适配指南

> **【研究者严正声明（D级）】**
> 本文件中的工作流、输入输出清单、结构化控制协议以及“视觉一致性档案（Visual Consistency Bibles）”体系，均为研究者团队将 Rick Carter 的核心方法论（A/B/C级证据）蒸馏后，面向当代及未来 AI 影视生产管线（LLM、文生图/图生图、AI 视频、三维资产生成与 Blender 管线）提出的**工程适配方案（D级推断）**。
> Carter 本人在 2025 年访谈中明确表示自己仅对生成式 AI 有“极少量的接触（minimal experience）”，但他将 AI 视为“合作伙伴而非单纯的工具（a partner and not a tool）”，认为是自数字革命以来世界观构建（world building）领域的最新自然演进（A级）。**本文件中的具体工程表单与固定文件体系并非 Carter 本人在过往传统或数字电影制作中使用过的固有文件制度。**

---

## 一、 核心设计哲学向 AI 生产管线的映射（A级基线 → D级工程映射）

在将 Carter 的方法转化为 AI 流程前，必须在系统顶层写入三条“反 AI 常见通病”的底层铁律：

1. **反“视觉糖果（Eye Candy）”铁律**：Carter 在反思《Sucker Punch》时指出，如果场景对于所发生的故事而言过于繁复，就会沦为纯粹讨好眼球的无意义装饰（gratuitous eye candy）（A级）；在 2025 年访谈中他进一步指出，“当观众在赞叹制作设计时，他们已经出戏了（When you’re admiring production design, you’re not into the movie）”（A级）。因此，AI 生成提示词严禁无节制堆砌“史诗感、极致细节、华丽光影”等标签，一切视觉复杂度必须受控于叙事功能（D级）。
2. **反“全知全见”铁律**：在《Avatar》剧本阅读中，Carter 领悟到“当你看到一切时，你什么也没看到（When you see everything, you see nothing）”（A级）。AI 管线不能在一开始就跳过宏观情绪去生成琐碎的局部材质，必须先建立“引导式意象（Guided Imagery）”与核心情感锚点（A级→D级）。
3. **“形式与内容合一”铁律**：无论是《A.I.》随叙事从实体摄影棚逐步过渡到纯数字冰封世界（A级），还是《The Fabelmans》用三栋房子锚定三幕成长寓言（A级），技术手段与空间形态的切换必须直接外化人物的内心旅程（Journey Motif）（A级→D级）。

---

## 二、 五大 AI 生产模块全流程规范（D级工程方案）

### 模块 A：从剧本到世界观设计（Script-to-Worldbuilding LLM Agent）

本模块模拟 Carter 早期介入项目的状态——在没有既定视觉方案时，通过提出哲学与核心叙事问题（如在《The Force Awakens》中追问“原力在今天意味着什么？”）以及与导演“思维融合（mind-melding）”（A/B级），把文字转化为世界观架构。

#### 1. 输入清单（Inputs）
*   **剧本全本或分场大纲（Script / Treatment）**：提取故事的时代背景、地域转换与幕结构（对应 Carter 分析《A.I.》四幕结构或《The Fabelmans》三栋房子三幕结构的做法，A级）。
*   **导演核心愿景与母题（Director's Vision & Core Motif）**：导演过往的视觉经验或执念（如卡梅隆在深海考察中获得的生物发光体验，A级；或斯皮尔伯格童年记忆的二元性，A级）。
*   **制作约束条件（Production Constraints）**：预算体量、制作周期、是否要求在特定地理半径内完成（如《The Fabelmans》限制在洛杉矶 30 英里内，《The Post》要求 8 周内开机，A级）。
*   **电影类型维度判定（Horizontal vs. Vertical Axis）**：横向扩张型史诗（Horizontal，需填满宏大世界）还是纵向内省型戏剧（Vertical，需向人物内心深挖细节）（A级）。

#### 2. 处理逻辑（Agent Processing Steps）
*   **Step 1：哲学叩问与“引导式意象（Guided Imagery）”生成**：不直接画分镜，先由 LLM 提炼 3 个关于本片精神内核的根本问题（A级），产出纯粹象征性的概念描述（如《The Force Awakens》中“把光芒从恒星中抽走作为武器”的视觉概念，或《The BFG》中“像大脑与突触一样的橡树与倒影池”，A级）。
*   **Step 2：旅程母题（Journey Motif）与空间映射**：梳理主角“离家—闯入未知世界—回归/无法回归”的轨迹（A级），将剧本切分为具有鲜明对比的“现实圈层（Kansas）”与“异世界圈层（Oz）”（A级）。
*   **Step 3：预算倒逼优先级裁剪（Inside-Out Prioritization）**：检查剧本中是否存在昂贵但非情感核心的外景（如《Lincoln》早期的大量战场戏，A级），提出删减或内景化建议，将资源集中于核心心理空间（如林肯的白宫办公室与居住层，A级）。

#### 3. 输出清单（Outputs）
*   `World_Philosophy_&_Portal_Concept.json`：包含核心视觉隐喻（Portal Idea）、“堪萨斯 vs 奥兹国”二元色彩/材质对立表（A/D级）。
*   `Macro_Structure_Map.md`：按幕划分的世界演变路径（如实体感→超现实感→数字感）（A/D级）。
*   `Budget_Reallocation_Proposal.md`：标注“高优重金核心场景”与“极简降级外景（如无招牌街道）”的工程建议书（A/D级）。

---

### 模块 B：场景空间设计（Spatial & Architectural Design Module）

> **【硬性工程约束】**
> Carter 本人坦承自己“画不好建筑背景（trouble really drawing architecture）”，因此高度依赖优秀的布景设计师（Set Designers）和建筑师将他的概念草图与情感诉求转化为精确的三维空间与平面布局（A级）。**在 AI 管线中，场景设计模块绝不能只输出一段用于生图的形容词提示词（Prompt），必须输出包含三维空间拓扑、动线、机位框景与心理分区的结构化空间描述（D级）。**

#### 1. 场景设计结构化输出规范（Scene Spatial Specification）
每个独立场景必须输出以下 6 个维度的三维空间结构描述：

1.  **三维拓扑与轴线布局（3D Topology & Axial Layout）**
    *   明确房间的长宽高比例、核心轴线与出入口位置。
    *   *方法论依据*：《The Fabelmans》新泽西住宅中，依据斯皮尔伯格手绘平面图，将楼梯严格居中，右侧设为父亲的客厅（理性/科技），左侧设为母亲的餐厅（艺术/感性），后方连接厨房，通过空间拓扑建立人物关系的二元对立（A级）；《The Post》将两位主角的住宅背靠背搭建在同一摄影棚，形成“罗密欧与朱丽叶”式的空间呼应（A级）；《Six Million Dollar Man》中一扇门位置放错直接导致导演无法按计划拍摄（A级）。
2.  **公私心理分区与走廊动线（Public/Private Zoning & Circulation）**
    *   定义公共展示区（Presentational/Official）、过渡区（Common Hallway）与私密心理区（Intimate/Sanctuary）的物理连接关系。
    *   *方法论依据*：《Lincoln》中将民众聚集的公共走廊紧贴林肯的办公与居住区布置，形成全片的情感心脏（A级）。
3.  **景深三层照明与物理框景结构（Depth Layering & Architectural Framing）**
    *   在三维空间中强制预留前景（Foreground）、中景（Middle ground）、后景（Background）的物理遮挡物与透视开口。
    *   *方法论依据*：Carter 在《Lincoln》中专门为斯皮尔伯格与摄影指导卡明斯基设计窗帘（框住窗户）、拱门（框住人物）、壁炉（框住火焰），以配合外景光、煤气灯光与眼神光形成三层景深（A级）。
4.  **视点高度与体量压迫感参数（POV Height & Scale Dynamics）**
    *   标注关键观察者的视线高度（Eye-level）及与建筑体量的比例关系。
    *   *方法论依据*：Carter 在 ADG 演讲中强调“5尺4寸的人和6尺7寸的人看到的世界完全不同（高个子能看见冰箱顶上的灰）”（B级）；《Jurassic Park》用极简但巨大尺度的围栏和重体量混凝土几何形制造“不可摧毁的堡垒感”（C级）。
5.  **叙事演进状态机（Narrative State Machine）**
    *   同一空间在不同幕次中的物理状态变化描述。
    *   *方法论依据*：《Jurassic Park》控制室在第一幕是杂乱但安全的科技掩体，第三幕在同一物理结构下转化为被围困的末日指挥所（C级）。
6.  **叙事性陈设锚点（Illustrative Set Dressing Anchors）**
    *   在空间坐标中锁定承担“无台词叙事”的关键陈设位置。
    *   *方法论依据*：《The Fabelmans》女友卧室中并置的耶稣海报、摇滚明星海报與粉光十字架，或约翰·福特办公室墙上专门用于演示“高低地平线”的复制画作（A级）。

---

### 模块 C：AI 图像生成控制（AI Image Generation & Visual Constraints）

为避免文生图模型（如 Midjourney / Stable Diffusion / Flux）在同一世界观下产生建筑形制、时代特征与材质质感的随机漂移（Drift），必须建立以下三层约束机制（D级）：

#### 1. 历史与物理材质防伪约束（Anti-Synthetic Material Constraint）
*   **问题根源**：Jim Erickson 在《Lincoln》中指出，电脑生成的壁纸做不出传统丝网印刷的金属光泽与釉面质感，且历史细节一旦出错就会“像霓虹灯一样跳出来”（B级）。AI 图像极易产生光滑、塑料感或超越时代的合成质感。
*   **控制策略**：
    *   在全局负面提示词（Negative Prompts）与 ControlNet 材质参考中，封锁现代数字平滑表面。
    *   引入**“工匠二次做旧层（Artisan Alchemy Layer）”**：模拟《Back to the Future Part II》中现场绘景师用景泰蓝（cloisonné）药水喷洗过于艳丽的红金壁纸，将其压暗转化为银紫色的过程（A/B级）。在 AI 图像管线中，严禁直接使用文生图直出结果作为最终资产，必须经过一层基于真实历史织物/丝网印/风化混凝土采样图的 Image-to-Image 质感覆盖与明度压制（把门框饰条压暗以突出壁纸层次，如《Lincoln》做法，A级）（D级）。

#### 2. 时代技术逆向锁定（Retro-Tech Aesthetic Lock）
*   **方法论依据**：在《The Force Awakens》中，Carter 与 Gilford 确立了“就像这些布景和载具是 1970 年代造出来的”以及回溯 Ralph McQuarrie 原始手绘草图的原则（A/B级）。
*   **控制策略**：当设计具有历史传承或特定美学基因的世界时，将基底风格模型（LoRA / Style Reference）锁定在特定年代的实体工业设计或手绘概念图上，禁止 AI 自动混入当代流线型科幻元素，确保“视觉历史可解释但不必解释”（B级→D级）。

#### 3. 建筑形制与表面材料的语义绑定（Form-Material Semantic Binding）
*   **方法论依据**：《Jurassic Park》游客中心与围栏大量使用原始粗粝混凝土（raw concrete），既暗示史前开凿感，又因为“它只是混凝土而非真石头”暗合主题公园的虚假人造本质（C级）。
*   **控制策略**：在生图协议中将“建筑几何母题（重体量、圆形、扶壁）”与“唯一指定核心材质（粗粝混凝土、外露线缆）”强绑定，形成固定 Token 组合，防止同一建筑群在不同镜头中变成玻璃幕墙或真石材（D级）。

---

### 模块 D：AI 视频生成控制（AI Video Generation & Spatial Continuity）

> **【硬性工程禁令（D级）】**
> **严禁在生产管线中假设“单条文本提示词（Single Text Prompt）”能够稳定控制复杂三维空间的透视关系与跨镜头连续性！**
> Carter 在回顾《A.I.》中“红城（Rouge City）”的制作时明确指出，当角色与移动摄影机在数字环境中运动时，核心技术难点在于**空间追踪（Tracking）与视差变化（Parallaxing views shifting with the moving camera）**，必须确保前景实拍角色与后景数字环境在三维空间中的几何关系完全吻合（A级）。单靠文本提示词驱动的 AI 视频必然导致视差崩塌与门窗移位。

#### 1. 强制三维粗模与相机轨迹先行（3D Blockout & Camera Pass First）
*   任何涉及移动机位或超过 2 个镜头的场景，必须先在三维软件中根据【模块 B】的空间拓扑生成白模（White-box Blockout），渲染出深度图（Depth Map）、法线图（Normal Map）与相机运动视差序列，作为 AI 视频模型（如 Runway Gen-3 / Sora / Kling + ControlNet 视频管线）的刚性结构输入（D级）。

#### 2. 多光源分层渲染约束（Multi-Layer Lighting Constraint）
*   参考《Lincoln》中支持摄影指导的三种光源逻辑（自然外景光、室内煤气灯人造光、照亮眼睛或勾勒剪影的戏剧光，A级），以及用真实旧煤气灯在暗室测试照度的做法（B级）。AI 视频生成不得使用笼统的“cinematic lighting”提示词，必须通过光影遮罩（Lighting Matte）规定主光源的物理衰减半径（如单盏煤气灯的真实照度范围），维持前景、中景、后景的明暗分离度（D级）。

#### 3. 空间过渡门户（Portal Transitions）的连续性锁定
*   Carter 极度重视从一个世界跨入另一个世界的“门户时刻”（如《绿野仙踪》推门从黑白进入彩色，A级）。在 AI 视频生成跨空间长镜头时，必须以“门框/拱门/走廊拐角”作为关键帧硬切点或遮罩缝合点，分段控制两侧空间的色彩与材质参数（D级）。

---

### 模块 E：三维 / Blender 工程管线规范（3D / Blender Pipeline Specifications）

Carter 在《Polar Express》与《Avatar》中深度参与了动作捕捉空间（Motion-capture Volume）、实时可视化（Real-time Visualization）与实景搭建的混合流程（Hybrid Pipeline）（A级）。面向 Blender / Unreal Engine 等三维管线，制定以下 6 项交付标准（D级）：

#### 1. 尺寸比例与视线校准（Scale & Eye-Level Calibration）
*   **绝对尺寸错误防御**：Carter 曾因早期经验不足，在《Back to the Future Part II》中将未来小巷搭宽了 4 英尺（耗时耗资 7 万美元返工），并将中产阶级公寓搭得过大被导演 Zemeckis 当场指出（A级）。
*   **Blender 规范**：所有场景必须导入标准人体比例尺（含 5尺4寸与 6尺7寸双视点相机高度，B级）以及阶层/功能尺寸基准框（如“中产阶级客厅最大长宽限制”），在白模阶段进行广角与长焦镜头的视场角（FOV）挤压测试，确认无误后方可进入细化建模（D级）。

#### 2. 模型资产分级清单（Tiered Asset Manifest）
*   **A 级核心叙事资产（Hero Narrative Assets）**：如《Lincoln》林肯办公室家具、《War Horse》带铁丝网的战壕道具（A级），需高精度拓扑与独立 UV。
*   **B 级架构框景资产（Framing Architectural Assets）**：如拱门、窗框、壁炉、托马斯·杰斐逊设计的门廊柱式（A级），用于组织镜头景深，需精确几何比例。
*   **C 级背景减法资产（Subtractive Background Assets）**：遵循《Lincoln》华盛顿外景“没钱做招牌就彻底不放招牌、只铺泥土遮盖现代痕迹”（A级）的原则，非叙事焦点区域严禁堆砌高精度杂物模型（D级）。

#### 3. 材质着色器参数（Material & Shader Parameters）
*   **壁纸/织物 Shader**：针对历史场景，必须在 Blender 节点中加入丝网印刷（Silkscreen）特有的微凸起法线与角度相关的金属釉面反射（Anisotropic Glaze），避免纯漫反射贴图的扁平感（A/B级→D级）。
*   **色彩心理对比参数**：在同一楼层或相连空间中，通过材质球的基础色相（Base Color Hue）建立明确的心理属性区分（如林肯办公室的官方沉稳绿色 vs 玛丽卧室具有通灵精神特质的紫色，A级；沙漠住宅的暖木色调，A级）（D级）。
*   **现场调色覆写节点（On-Set Paint Wash Node）**：在所有主材质节点末端预留一个全局“喷洗压暗（Cloisonné / Dingy Wash）”混合节点（源自 Biff 公寓壁纸教训，A级），允许灯光师与美术指导在最终渲染前一键压低过饱和的色彩明度（D级）。

#### 4. 摄影机可见区与剔除（Camera Frustum & Culling Zones）
*   结合导演手绘平面图（如斯皮尔伯格在《The Fabelmans》中的做法，A级），在 Blender 中标出主摄影机视锥体（Frustum）。视锥体外的区域仅保留物理反射所需的简模；视锥体内的前景、中景、后景交界处重点布置框景几何体（A级→D级）。

#### 5. 人物行动区与动捕映射（Character Blocking & MoCap Volume）
*   在三维场景地面用网格明确标注演员/虚拟角色的行动热区（Blocking Zone）：如《Lincoln》中访客从公共走廊直通办公室的动线（A级），确保门的位置、家具间距完全服务于调度（吸取《Six Million Dollar Man》门位错误的教训，A级→D级）。

#### 6. 实体与数字划分矩阵（Physical vs. Digital Split Matrix）
*   依据《A.I.》与《Avatar》的混合制作经验（A级），在三维总装文件中用颜色编码区分：
    *   **绿色（Physical Build / 近景高交互区）**：演员直接触摸、坐卧、发生强烈情感戏剧的室内核心区（必须具备最高触觉真实度）。
    *   **黄色（Hybrid Extension / 中景视差衔接区）**：实景局部搭建（如在议会大厦北侧加装一个门廊即充当白宫外景，A级）结合数字延伸，需严格对齐相机追踪点（Tracking Markers）。
    *   **蓝色（Pure Digital Realm / 远景或超现实演化区）**：物理世界无法企及的尺度或时间跨度（如《A.I.》跨越两千年后的冰封世界、《Avatar》潘多拉生物发光丛林，A级）。

---

## 三、 AI 视觉一致性工程档案体系（Visual Consistency Bibles）

> **【工程交付物声明（D级）】**
> 以下 8 份档案（Bibles & Registries）是研究者为解决 AI 生成管线中的“上下文遗忘”与“跨模态视觉漂移”而设计的**标准化 JSON/Markdown 工程交付物**。Rick Carter 本人的工作方式高度依赖直觉、情感共鸣、拼贴画（如《The Post》中像劳申伯格作品一样的大拼贴画，A级）以及与概念艺术家、工匠的直接对话（“像玩比划猜词游戏一样捕捉微弱的灵感低语”，A级），**他本人并不使用这套僵化的数据库文件体系。**

### 1. `World_Bible.md`（世界观圣经）
*   **核心字段**：
    *   `Core_Philosophical_Question`：驱动视觉设计的根本提问（如“原力在今天意味着什么？”“第四维度在胶片上存在于何处？——帧与帧之间的黑场”，A级）。
    *   `Portal_Metaphor`：连接日常世界与奇观世界的入口定义（Kansas vs. Oz 转换规则，A级）。
    *   `Timeline_Evolution_Rule`：世界随叙事时间推移的形态退化或升华法则（如《A.I.》从家庭温室→霓虹红城→水下→两千年后冰封数字世界，A级）。

### 2. `Environment_Bible.md`（宏观环境圣经）
*   **核心字段**：
    *   `Bioluminescence_&_Atmosphere`：自然环境的梦幻状态定义（如《Avatar》潘多拉夜晚的“phantasmagoric / 梦境般的”深海生物发光逻辑，A级）。
    *   `Geographic_&_Climate_Evolution`：单一环境概念的迭代约束（如《The Force Awakens》中 Jakku 星球最终锁定为“孤立的加油站式沙漠前哨”，B级）。
    *   `Exterior_Simplification_Rule`：低优先级外景的减法原则（如移除现代电线杆、铺土、不设多余商业招牌，A级）。

### 3. `Architecture_Bible.md`（建筑与空间圣经）
*   **核心字段**：
    *   `Spatial_Fable_Mapping`：建筑结构与家庭/人物关系的映射表（如《The Fabelmans》三栋房子对应家庭从聚合到分裂的三幕；楼梯居中切分父母领地，A级）。
    *   `Geometric_Language`：建筑体量与几何母题（如《Jurassic Park》的粗野主义重体量、圆窗、扶壁，C级）。
    *   `Framing_Devices_Spec`：强制用于辅助摄影构图的建筑构件清单（拱门、窗框、壁炉开口尺寸，A级）。
    *   `Scale_Guardrails`：防止空间尺寸失真的硬性长宽高上限（吸取《Back to the Future Part II》小巷过宽与公寓过大教训，A级）。

### 4. `Props_Bible.md`（道具与陈设圣经）
*   **核心字段**：
    *   `Silent_Storytelling_Dressing`：无需台词即可交代人物处境的陈设组合（如女友房间的宗教与摇滚海报混搭，A级）。
    *   `Pedagogical_&_Thematic_Props`：直接承载电影美学或主题说明功能的道具（如约翰·福特办公室高低地平线画作，A级；《War Horse》缠绕在马身上的铁丝网象征荆棘冠与十字架，A级）。
    *   `Archival_Authenticity_Standard`：历史文件与地图的原件级复刻要求（一旦失真会“像霓虹灯一样刺眼”，B级）。

### 5. `Material_Bible.md`（材质与工艺圣经）
*   **核心字段**：
    *   `Primary_Tactile_DNA`：世界的主导材质及其叙事双重性（如《Jurassic Park》原始混凝土兼具“史前粗粝感”与“人造主题公园本质”，C级）。
    *   `Traditional_Craft_Simulation`：必须模拟传统工艺（如丝网印刷壁纸的金属光泽与釉面、古法织造地毯）而禁止使用纯数字平滑纹理的材质列表（A/B级）。
    *   `Aging_&_Distressing_Protocol`：表面做旧与色彩压制流程（Cloisonné 药水喷洗转化法则，A级）。

### 6. `Color_Bible.md`（色彩心理圣经）
*   **核心字段**：
    *   `Dichotomy_Palette`：公共/官方空间与私密/精神空间的色彩对立表（如《Lincoln》办公室的官方绿 vs 玛丽卧室的通灵紫，A级）。
    *   `Regional_&_Emotional_Shift`：跨地域/跨幕次的整体色调迁移（如《The Fabelmans》新泽西雪景→凤凰城沙漠木色→加州阴郁手工艺风色调，A级）。
    *   `Contrast_Trim_Rule`：墙面壁纸与木质饰条（Trim）的明度反差值设定（压暗饰条以凸显壁纸与空间轮廓，A级）。

### 7. `Scene_Asset_Registry.json`（场景资产注册表）
*   **核心字段**：
    *   `Asset_ID` / `Scene_ID` / `Narrative_Priority_Score`（根据情感权重打分，决定预算与算力倾斜度，A级→D级）。
    *   `Realization_Mode`：`Physical_Stage` | `Location_Modified` | `Hybrid_Tracked` | `Full_Digital`（A级→D级）。
    *   `Reusability_&_Modification_Tag`：资产跨场景改造记录（如利用杰斐逊设计的州议会大厦加装门廊改造为白宫外景，A级）。

### 8. `Continuity_Rules.md`（跨镜头与跨模态连续性守则）
*   **核心字段**：
    *   `Parallax_&_Tracking_Lock`：移动镜头中前景人物与后景环境的视差锁定校验规则（源自《A.I.》红城镜头经验，A级）。
    *   `Door_&_Portal_Coordinate_Lock`：所有出入口、门窗在三维坐标系中的绝对锁定，未经导演与摄影确认严禁任何 AI 模块自动微调位置（源自《Six Million Dollar Man》门位教训，A级）。
    *   `Light_Source_Physicality_Rule`：同一场景跨镜头切换时，历史光源（如煤气灯）的物理亮度和色温衰减必须保持恒定（B级→D级）。
