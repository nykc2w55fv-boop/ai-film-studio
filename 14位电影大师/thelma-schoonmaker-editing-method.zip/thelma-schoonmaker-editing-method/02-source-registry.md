# 02｜来源登记表

访问日期统一为 **2026-11-06**。A 级指本人直接访谈、正式讲座/逐场说明或官方署名记录；B 级指直接合作人员或制作团队的证言；C 级指专业媒体的二手分析。未用 D 级网络内容作为核心证据。

| source_id | 标题 / 作者 | 日期 | 作品 | 等级 | 原始链接 | 可支持的结论 | 不能支持的结论 |
|---|---|---|---|---|---|---|---|
| S01 | AFI Catalog: Thelma Schoonmaker | 动态目录；访问 2026-11-06 | 署名目录 | A | https://catalog.afi.com/Catalog/PersonDetails/146090 | AFI 收录的正式剪辑署名与年份 | 未列出的后期作品不代表她没有参与；不能替代每部影片的完整片尾字幕 |
| S02 | 53rd Academy Awards, 1981 | 1981 | Raging Bull | A | https://www.oscars.org/oscars/ceremonies/1981 | 《愤怒的公牛》最佳剪辑获奖 | 不能证明获奖的具体原因或方法 |
| S03 | 77th Academy Awards, 2005 | 2005 | The Aviator | A | https://www.oscars.org/oscars/ceremonies/embed/2005 | 《飞行家》最佳剪辑获奖 | 不能证明全部后期工作由她单独完成 |
| S04 | 79th Academy Awards, 2007 | 2007 | The Departed | A | https://www.oscars.org/oscars/ceremonies/2007 | 《无间行者》最佳剪辑获奖 | 不能推导某种风格公式 |
| S05 | 63rd Academy Awards, 1991 | 1991 | Goodfellas | A | https://www.oscars.org/oscars/ceremonies/1991 | 《好家伙》最佳剪辑提名 | 不能证明提名对应某个具体场景 |
| S06 | 84th Academy Awards, 2012 | 2012 | Hugo | A | https://www.oscars.org/oscars/ceremonies/2012 | 《雨果》最佳剪辑提名 | 不能证明 3D 剪辑细节 |
| S07 | 92nd Academy Awards, 2020 | 2020 | The Irishman | A | https://www.oscars.org/oscars/ceremonies/embed/2020 | 《爱尔兰人》最佳剪辑提名 | 不能证明具体编辑决策 |
| S08 | 96th Academy Awards, 2024 | 2024 | Killers of the Flower Moon | A | https://www.oscars.org/oscars/ceremonies/2024 | 《花月杀手》最佳剪辑提名 | 不能证明影片结构是剪辑师单独决定 |
| S09 | Thelma Schoonmaker: Fellowship 2019, BAFTA | 2019-02-08 | 职业经历 | A/C | https://www.bafta.org/stories/thelma-schoonmaker-fellowship-2019/ | 职业阶段、合作关系、纪录片到剧情片的路径、她关于“humanity”的自述 | 不能将 Scorsese 的导演决策都归给她 |
| S10 | A Pinewood Dialogue with Thelma Schoonmaker, Museum of the Moving Image | 2002-11-24 | Raging Bull、Woodstock、Goodfellas 等 | A | https://movingimagesource.us/files/dialogues/2/38564_programs_transcript_html_242.htm | 纪录片训练、即兴素材、双机位覆盖、冷眼观察、版本比较、音乐与剪辑 | 不能替代原始素材或完整剪辑项目文件 |
| S11 | Oscar-Winning Scorsese Editor Thelma Schoonmaker, Fresh Air / NPR | 2005-12-26（访谈录制于 2005 年） | Raging Bull、The Aviator | A | https://freshairarchive.org/segments/oscar-winning-scorsese-editor-thelma-schoonmaker | 拳赛蒙太奇、表演选择、即兴素材、声音抽离、镜像独白版本比较 | 不支持未提及的剪辑软件操作细节 |
| S12 | Thelma Schoonmaker & Martin Scorsese on Gangs of New York, CineMontage | 2003-01-01 | Gangs of New York | A | https://cinemontage.org/schoonmaker-scorsese-gangs-new-york/ | 开场序列、jump cut、音乐、战斗蒙太奇、男孩反应镜头、初剪删减 | 不能把 Scorsese 的拍摄设计归于 Schoonmaker |
| S13 | Thelma Schoonmaker, Film Comment | 2014-03/04 | The Wolf of Wall Street | A | https://www.filmcomment.com/interview-thelma-schoonmaker/ | 可见/不可见剪辑、即兴表演、连续性与表演的取舍、四小时初剪 | 不支持“连续性完全不重要”这种扩大解释 |
| S14 | Wolf of Wall Street Editor Thelma Schoonmaker..., Vanity Fair | 2014-01-07 | The Wolf of Wall Street | A | https://www.vanityfair.com/hollywood/2014/01/wolf-of-wall-street-editor-thelma-schoonmaker-there-s-nothing-like-a-handsome-actor-making-fun-of-himself | 午餐戏的快慢节奏对比、演员即兴、观众反应 | 不支持所有节奏设计均由剪辑师独立提出 |
| S15 | Cutting to the Chase with Thelma Schoonmaker, POV Magazine | 2024-05-13 | Woodstock、Raging Bull、数字剪辑 | A | https://povmagazine.com/cutting-to-the-chase-with-thelma-schoonmaker/ | Woodstock 多画面、纪录片方法、数字剪辑、工具观点、技术演变 | 不能将其关于数字保存的个人判断当作完整档案标准 |
| S16 | KEYNOTE: Academy Award-Winning Editor Thelma Schoonmaker, Post Magazine | 2005-11-16 | Raging Bull、Goodfellas、Lightworks | A | https://www.postmagazine.com/publications/2005/nab-post/keynote-academy-award-winning-editor-thelma-schoonmaker/ | 拳赛多速度素材、声音工作、临时混音、Lightworks 使用细节 | 不能把音效团队成果归于画面剪辑师 |
| S17 | Art of the Cut with Thelma Schoonmaker on Silence, ProVideo Coalition | 2017-01-14 | Silence | A | https://www.provideocoalition.com/art-of-the-cut-thelma-schoonmaker/ | 开场声音、节奏、正式对峙场面、Lightworks 轨道与同步工作 | 不能将导演的镜头调度完全归为剪辑师创作 |
| S18 | Thelma Schoonmaker Talks of Editing... The Irishman, CineMontage | 2019-12-02 | The Irishman | A | https://cinemontage.org/thelma-schoonmaker-talks-of-editing-aging-and-endings-in-martin-scorseses-the-irishman/ | 影片节奏意图、即兴、结构、去龄流程、安静与暴力的处理 | 不能把 VFX 技术开发归于剪辑师 |
| S19 | The Irishman’s Oscar-Nominated Editor..., The Credits / Motion Picture Association | 2020-01-22 | The Irishman、Raging Bull | A | https://www.motionpictures.org/2020/01/the-irishmans-oscar-nominated-editor-thelma-schoonmaker-on-her-53-year-collaboration-with-martin-scorsese/ | 多版本、line reading、洗衣店停顿、慢速累积、冷眼观察 | 不能提供完整逐帧时间码 |
| S20 | Killers of the Flower Moon: Editor Thelma Schoonmaker, Post Magazine | 2023-11-07 | Killers of the Flower Moon | A | https://www.postmagazine.com/press-center/video-film/2023/killers-of-the-flower-moon-editor-thelma-schoonmaker/ | dailies、assembly、试映、未写定演讲、演讲与尸检交叉剪辑、死亡场景 | 不能证明所有最终决定由她单独完成 |
| S21 | The Rough Cut: Telling the True Story of Killers of the Flower Moon, Frame.io | 2023-11-16；更新 2023-12-13 | Killers of the Flower Moon | A | https://blog.frame.io/2023/11/16/the-rough-cut-killers-of-the-flower-moon/ | 影片结构、角色视角、停顿、导演与剪辑师的合作 | 不能证明访谈中未讨论的版本历史 |
| S22 | Thelma Schoonmaker Talks Editing Martin Scorsese’s Killers of the Flower Moon, CineMontage | 2024-02-01 | Killers of the Flower Moon | A | https://cinemontage.org/thelma-schoonmaker-talks-editing-martin-scorseses-killers-of-the-flower-moon/ | Mollie 旁白、爱情线重组、表演、角色复杂性 | 不能将演员参与剧本修订归于剪辑师 |
| S23 | Inside the Sound of Killers of the Flower Moon, Mixonline | 2023-12-06 | Killers of the Flower Moon | B | https://www.mixonline.com/sfp/inside-the-sound-of-killers-of-the-flower-moon | Eugene Gearty、Tom Fleischman 等声音团队的分工与混音实践 | 不能证明所有声音选择由 Schoonmaker 决定 |
| S24 | 8 Lessons Thelma Schoonmaker Taught Us at TFF 2014, Tribeca | 2014-04-19 | Raging Bull | B | https://tribecafilm.com/news/thelma-schoonmaker-martin-scorsese-raging-bull-tribeca-film-festival | 大师课内容摘要、拳赛、音效和覆盖实践 | 属于活动报道摘要，不等同完整讲座逐字稿 |

## 使用说明

- 引用格式：`[Sxx]`，对应本表的 source_id。
- 直接引语只保留极短片段；正式 Skill 应以中文准确转述为主。
- 若来源观点属于 Scorsese、声音团队或 VFX 团队，必须在具体方法卡中保留署名边界。
- 网页存档、采访日期和作品年份不同的情况，按原来源记录，不擅自统一。
