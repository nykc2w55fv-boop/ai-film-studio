# 11｜AI 影视剪辑工程适配

## 1. 总体原则

本节是工程设计，不是 Schoonmaker 本人提出的软件规范。它将前述可证实方法转换成工具无关的剪辑流程，可由 ChatGPT、Codex、本地脚本、FFmpeg、Blender 或非线性剪辑软件执行。不能假设所有工具已经安装。

## 2. 输入到剪辑计划

### 输入

- 剧本和分场。
- 人物关系与人物目标。
- 导演意图和节奏要求。
- 分镜与镜头表。
- 视频素材、音频素材和时间码。
- 目标片长、帧率和交付规格。

### 输出

- 场景剪辑目标。
- 必须呈现的信息。
- 关键表演时刻和反应候选。
- 节奏变化点。
- 镜头覆盖需求。
- 声音衔接需求。
- 素材缺口清单。
- 需要人工确认的决定。

## 3. 素材分析流水线

### 3.1 可自动检测

- 文件格式、时长、分辨率、帧率、采样率。
- 视频黑帧、静帧、音频静音、削波和明显失真。
- 镜头边界候选、场景切换候选。
- 音画同步偏差。
- 人物、服装、道具和空间的可见变化候选。
- 语音转写、说话者分离候选。
- 素材重复、近似镜头和版本关系。

### 3.2 需要模型辅助或人工判断

- 表演是否真实、有力量。
- 停顿是否有戏剧价值。
- 反应镜头是否改变人物关系。
- 某个镜头是否值得保留。
- 蒙太奇是否形成情绪或信息逻辑。
- 音乐是否具有正确的心理含义。
- 观众是否理解复杂叙事。

机器可检测的信息不等于艺术判断。所有模型判断都应附置信度和复核状态。

## 4. 中间编辑数据结构

### 4.1 时间基准

建议所有剪辑时间统一使用整数帧和整数音频采样点，不使用浮点秒数作为唯一真值。

- 序列帧率使用有理数：`fps_num / fps_den`。
- 视频源素材保留原始帧率、时间基准和是否可变帧率（VFR）。
- 若素材为 VFR，应保留原始 PTS 映射，或生成经过验证的 CFR 代理；不可简单把帧号当真实时间。
- `source_in` 为包含起点，`source_out` 为不包含终点（半开区间）。
- `timeline_in` 为包含起点，`timeline_out` 为不包含终点。
- 音频位置以采样点或明确的音频 timebase 表示。
- 音画同步偏移以整数采样点或精确时间基准保存。

### 4.2 时间线 JSON 示例

```json
{
  "project_id": "demo-project",
  "sequence_id": "seq-001",
  "sequence": {
    "fps_num": 24,
    "fps_den": 1,
    "audio_sample_rate": 48000,
    "timecode_format": "HH:MM:SS:FF",
    "drop_frame": false,
    "color_space": "未指定"
  },
  "media": [
    {
      "media_id": "M001",
      "source_file": "media/shot_001.mov",
      "source_fps_num": 24,
      "source_fps_den": 1,
      "source_duration_frames": 240,
      "audio_sample_rate": 48000,
      "vfr_normalized": true,
      "checksum_sha256": "待生成"
    }
  ],
  "clips": [
    {
      "clip_id": "C001",
      "media_id": "M001",
      "source_file": "media/shot_001.mov",
      "source_in": 24,
      "source_out": 96,
      "timeline_in": 0,
      "timeline_out": 72,
      "track": "V1",
      "scene_id": "SC01",
      "shot_id": "SH01",
      "audio_link": ["A001"],
      "transition": {"type": "cut", "duration_frames": 0},
      "playback_rate": {"num": 1, "den": 1},
      "editorial_intent": "保留人物反应形成停顿",
      "method_id": "TSM-05",
      "confidence": 0.78,
      "review_required": true
    }
  ],
  "audio_clips": [
    {
      "audio_clip_id": "A001",
      "source_file": "media/dialogue_001.wav",
      "source_in_sample": 48000,
      "source_out_sample": 192000,
      "timeline_in_sample": 0,
      "timeline_out_sample": 144000,
      "track": "A1",
      "sync_offset_samples": 0,
      "role": "production_dialogue"
    }
  ],
  "version": {"name": "assembly_v001", "parent": null}
}
```

以上为结构示例，不是真实电影素材或真实剪辑时间线。

### 4.3 必须保留的字段

至少包括：

- `clip_id`
- `source_file`
- `source_in`
- `source_out`
- `timeline_in`
- `timeline_out`
- `track`
- `scene_id`
- `shot_id`
- `audio_link`
- `transition`
- `editorial_intent`
- `method_id`
- `confidence`
- `review_required`

推荐增加：`media_id`、`playback_rate`、`source_fps_num`、`source_fps_den`、`source_timebase`、`sync_offset_samples`、`version_id`、`checksum`、`rights_status`、`review_reason`。

## 5. 自动时间线生成

1. 先按场景、事件和人物状态分组素材。
2. 为每个场景生成一个可读的基础连续性版本。
3. 对表演、反应、停顿、蒙太奇和音乐分别生成可比较候选。
4. 仅在事件依赖关系允许时重排镜头。
5. 每个剪辑片段都保留源文件与源时间范围。
6. 输出时间线前，校验帧率、半开区间、轨道重叠、音画同步和媒体存在性。
7. 对不确定的表演和叙事判断设置 `review_required=true`。

## 6. FFmpeg 与非线性剪辑软件分工

### 适合 FFmpeg / 脚本完成

- 素材探测、代理转码、截取和基础拼接。
- 音视频格式统一。
- 基础速度调整、淡入淡出、响度分析。
- 字幕烧录、音轨映射、导出和文件校验。
- 自动生成低分辨率审阅版。

### 需要 NLE 或人工判断

- 多 take 表演选择。
- 复杂即兴场景的反应镜头组织。
- 多线叙事结构重排。
- 音乐与人物表演之间的情绪取舍。
- 需要精细处理的音画同步和复杂多轨混音。
- 对导演意图、观众理解和表演真实性的最终判断。

FFmpeg 可以执行时间线操作，但简单拼接命令不能解决复杂叙事剪辑问题。

## 7. 自动修订循环

`初版剪辑 → 问题定位 → 修改假设 → 生成备选版本 → 对照检查 → 人工/导演确认 → 保存变更记录`

每次修改必须记录：
- 修改前后时间线版本。
- 影响的 clip_id。
- 使用的方法卡。
- 修改原因。
- 预期改善。
- 可能损失。
- 自动检查结果。
- 人工复核结论。

## 8. 必须阻止的自动化行为

- 素材不存在时凭空补造镜头。
- 未确认因果关系就重排人物动作。
- 因为节奏评分低而机械加快剪辑。
- 为音乐节拍破坏表演和叙事。
- 忽略音画同步和声音连续性。
- 把平均镜头时长当作质量评分。
- 把模型猜测的情绪当作人物真实心理。
- 未经确认自动删除关键停顿或反应。

## 9. 导出验收

- 所有媒体路径可解析。
- 时间线没有非法负时长或区间倒置。
- 音画同步在预设容差内。
- 帧率、分辨率、色彩空间与交付要求一致。
- 无意外黑帧、静音、削波和媒体离线。
- 关键人物、服装、道具和空间连续性通过检查。
- 最终版本附带变更日志、素材清单和待人工复核项。
